import { ContinuityState, Scene } from '../../src/types';

export class ContinuityService {
  /**
   * Initializes or extracts the core continuity parameters from the project prompt and style.
   */
  static extractContinuity(prompt: string, style: string): ContinuityState {
    const promptLower = prompt.toLowerCase();

    // Heuristics and fallback seeds for continuity attributes
    const isNight = promptLower.includes('night') || promptLower.includes('dusk') || promptLower.includes('evening');
    const isRain = promptLower.includes('rain') || promptLower.includes('wet') || promptLower.includes('storm');
    const isSavannah = promptLower.includes('savannah') || promptLower.includes('wildlife') || promptLower.includes('safari') || promptLower.includes('african');
    const isCyberpunk = promptLower.includes('neon') || promptLower.includes('cyberpunk') || promptLower.includes('futuristic');

    let lighting = isNight ? 'Moody nocturnal lighting with vibrant artificial luminescence' : 'Warm natural sunlight, crisp ambient diffusion';
    if (isRain && isNight) lighting = 'Wet asphalt reflections, dramatic neon rim lighting, high-contrast shadows';
    if (isSavannah) lighting = 'Warm golden hour sunrise, soft horizon haze, natural backlighting';

    let weather = 'Clear, atmospheric clarity';
    if (isRain) weather = 'Wet rain, mist and atmospheric drizzle';
    if (isSavannah) weather = 'Dry savannah heat shimmer with morning mist';

    let timeOfDay = isNight ? 'Night' : 'Golden hour / Daylight';

    return {
      characters: [],
      clothing: 'Consistent stylistic wardrobe matching scene context',
      locations: [],
      vehicles: promptLower.includes('car') ? 'High-end sleek vehicle matching core design' : '',
      objects: [],
      architecture: promptLower.includes('city') ? 'Contemporary urban architecture with reflective glass and street structures' : 'Natural organic landscape',
      lighting,
      weather,
      timeOfDay,
      colorPalette: isCyberpunk ? 'Deep midnight blues, electric cyan, vibrant magenta highlights' : 'Cinematic graded tones, natural organic hues',
      cameraStyle: 'Smooth cinematic tracking, stabilized steady-cam, fluid movement',
      visualStyle: style || 'Cinematic photorealistic 8K',
    };
  }

  /**
   * Generates a context-aware prompt for a scene, chaining from previous scene
   * to guarantee visual continuity and seamless narrative flow across long-form video.
   */
  static buildContextAwarePrompt(
    scenePrompt: string,
    previousScene: Scene | null,
    nextSceneSummary: string | null,
    continuity: ContinuityState,
    sceneIndex: number,
    totalScenes: number
  ): string {
    const parts: string[] = [];

    // If there is a previous scene, maintain explicit visual continuity
    if (previousScene) {
      parts.push(
        `Continuing directly and seamlessly from the previous shot: "${previousScene.prompt.slice(0, 150)}".`
      );
      parts.push(
        `Maintain identical visual continuity: preserve the same lighting (${continuity.lighting}), environment, weather (${continuity.weather}), color palette (${continuity.colorPalette}), and subject appearances without abrupt jarring shifts.`
      );
    } else {
      parts.push(`Opening establishing shot: ${scenePrompt}.`);
    }

    // Core scene visual action and composition
    parts.push(`Scene action: ${scenePrompt}.`);

    // Camera and motion instructions
    parts.push(`Camera direction: ${continuity.cameraStyle}. Smooth motion, pristine depth of field.`);

    // Style and aesthetic guardrails
    parts.push(`Aesthetic: ${continuity.visualStyle}, photorealistic, ultra-detailed textures, cinematic composition.`);

    return parts.join(' ');
  }
}
