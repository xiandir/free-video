import { GenerateVideosOperation } from '@google/genai';
import { getAiClient, isApiKeyConfigured } from './geminiClient';
import { StorageService } from './storageService';
import { AspectRatio, Resolution, Scene } from '../../src/types';

export class VideoGenerationService {
  /**
   * Generates a video clip using Google Veo via @google/genai SDK.
   * Handles asynchronous operation polling and downloads the output to persistent storage.
   */
  static async generateVideoClip(params: {
    scene: Scene;
    modelId: string;
    aspectRatio: AspectRatio;
    resolution: Resolution;
    audioEnabled: boolean;
    onProgress?: (status: string) => void;
  }): Promise<{
    success: boolean;
    clipUrl?: string;
    clipPath?: string;
    error?: string;
  }> {
    const { scene, modelId, aspectRatio, resolution, audioEnabled, onProgress } = params;

    if (!isApiKeyConfigured()) {
      return {
        success: false,
        error: 'Video generation is not configured yet. Add the required Google API credentials in the Secrets panel to enable generation.',
      };
    }

    const ai = getAiClient();
    if (!ai) {
      return {
        success: false,
        error: 'Google AI Studio client failed to initialize with provided credentials.',
      };
    }

    try {
      onProgress?.(`Submitting generation request to ${modelId}...`);

      const promptToUse = scene.contextAwarePrompt || scene.prompt;

      // 1. Submit video generation operation
      const operation = await ai.models.generateVideos({
        model: modelId,
        prompt: promptToUse,
        config: {
          numberOfVideos: 1,
          resolution: resolution === '4k' ? '1080p' : resolution, // Safety normalization
          aspectRatio,
        },
      });

      if (!operation || !operation.name) {
        return {
          success: false,
          error: 'Veo generation request did not return an operation name.',
        };
      }

      const operationName = operation.name;
      onProgress?.(`Job submitted: ${operationName}. Polling generation status...`);

      // 2. Poll until operation is complete
      let isDone = false;
      let attempts = 0;
      const maxAttempts = 120; // Up to ~10 minutes
      let completedOp: any = null;

      while (!isDone && attempts < maxAttempts) {
        await new Promise((r) => setTimeout(r, 5000));
        attempts++;

        try {
          const pollOp = new GenerateVideosOperation();
          pollOp.name = operationName;
          const updated = await ai.operations.getVideosOperation({ operation: pollOp });

          if (updated.done) {
            isDone = true;
            completedOp = updated;
            break;
          }

          onProgress?.(`Rendering clip with Veo (attempt ${attempts}/${maxAttempts})...`);
        } catch (pollErr: any) {
          console.warn(`Poll error on attempt ${attempts}:`, pollErr?.message);
        }
      }

      if (!isDone || !completedOp) {
        return {
          success: false,
          error: `Veo generation timed out after ${maxAttempts * 5} seconds.`,
        };
      }

      if (completedOp.error) {
        const errorMsg = completedOp.error.message || 'Video model returned an error.';
        return {
          success: false,
          error: `Veo generation error: ${errorMsg}`,
        };
      }

      // 3. Download the generated video to persistent storage
      const videoUri = completedOp.response?.generatedVideos?.[0]?.video?.uri;
      if (!videoUri) {
        return {
          success: false,
          error: 'No video URI returned in completed Veo operation.',
        };
      }

      onProgress?.('Downloading and storing generated clip...');
      const apiKey = process.env.GEMINI_API_KEY;
      const downloadRes = await fetch(videoUri, {
        headers: { 'x-goog-api-key': apiKey || '' },
      });

      if (!downloadRes.ok) {
        return {
          success: false,
          error: `Failed to download video from Veo provider (HTTP ${downloadRes.status}).`,
        };
      }

      const arrayBuffer = await downloadRes.arrayBuffer();
      const buffer = Buffer.from(arrayBuffer);

      // Persist clip to disk
      const { filePath, url } = await StorageService.uploadClip(scene.sceneId, buffer);

      return {
        success: true,
        clipUrl: url,
        clipPath: filePath,
      };
    } catch (err: any) {
      console.error('Veo video generation error:', err);
      const msg = err?.message || String(err);

      if (msg.includes('Resource has been exhausted') || msg.includes('429')) {
        return {
          success: false,
          error: 'Veo generation quota or rate limit exceeded. Please wait a moment before retrying.',
        };
      }

      if (msg.includes('Safety') || msg.includes('blocked')) {
        return {
          success: false,
          error: 'Generation was blocked by Google AI Safety policies. Please refine the scene prompt.',
        };
      }

      return {
        success: false,
        error: `Generation failed: ${msg}`,
      };
    }
  }
}
