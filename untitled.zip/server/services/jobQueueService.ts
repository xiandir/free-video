import { db } from '../database/db';
import { VideoGenerationService } from './videoGenerationService';
import { VideoAssemblyService } from './videoAssemblyService';
import { Project, Scene } from '../../src/types';

interface QueueItem {
  projectId: string;
  sceneId: string;
}

export class JobQueueService {
  private static activeJobs = new Set<string>(); // projectId:sceneId
  private static queue: QueueItem[] = [];
  private static cancelledProjects = new Set<string>();
  private static isProcessing = false;
  private static maxConcurrency = 2;

  /**
   * Starts or queues a project generation workflow.
   */
  static async startProject(projectId: string) {
    const project = db.getProjectById(projectId);
    if (!project) return;

    this.cancelledProjects.delete(projectId);

    // If project was DRAFT or QUEUED or FAILED or CANCELLED, start queueing
    project.status = 'GENERATING';
    project.currentStatusMessage = 'Queueing scenes for video generation...';
    db.saveProject(project);

    // Queue pending or failed scenes
    for (const chapter of project.chapters) {
      for (const scene of chapter.scenes) {
        if (scene.status !== 'COMPLETED') {
          // If scene is not already queued, add to queue
          const jobKey = `${projectId}:${scene.sceneId}`;
          if (!this.activeJobs.has(jobKey) && !this.queue.some(q => q.projectId === projectId && q.sceneId === scene.sceneId)) {
            scene.status = 'PENDING';
            this.queue.push({ projectId, sceneId: scene.sceneId });
          }
        }
      }
    }

    db.saveProject(project);
    this.processQueue();
  }

  /**
   * Retries only failed scenes for a project.
   */
  static async retryFailedScenes(projectId: string) {
    const project = db.getProjectById(projectId);
    if (!project) return;

    this.cancelledProjects.delete(projectId);
    project.status = 'GENERATING';
    project.currentStatusMessage = 'Retrying failed clips...';

    for (const chapter of project.chapters) {
      for (const scene of chapter.scenes) {
        if (scene.status === 'FAILED') {
          scene.status = 'PENDING';
          scene.error = undefined;
          this.queue.push({ projectId, sceneId: scene.sceneId });
        }
      }
    }

    db.saveProject(project);
    this.processQueue();
  }

  /**
   * Cancels ongoing generation for a project without deleting finished clips.
   */
  static cancelProject(projectId: string) {
    this.cancelledProjects.add(projectId);

    // Remove pending jobs from queue
    this.queue = this.queue.filter(q => q.projectId !== projectId);

    const project = db.getProjectById(projectId);
    if (project) {
      project.status = 'CANCELLED';
      project.currentStatusMessage = 'Generation cancelled by user. Completed clips preserved.';
      db.saveProject(project);
    }
  }

  /**
   * Processes queued scene jobs within concurrency limits.
   */
  private static async processQueue() {
    if (this.isProcessing) return;
    this.isProcessing = true;

    try {
      while (this.queue.length > 0 && this.activeJobs.size < this.maxConcurrency) {
        const item = this.queue.shift();
        if (!item) break;

        const { projectId, sceneId } = item;

        // Skip if project was cancelled
        if (this.cancelledProjects.has(projectId)) {
          continue;
        }

        const project = db.getProjectById(projectId);
        if (!project || project.status === 'CANCELLED') {
          continue;
        }

        const jobKey = `${projectId}:${sceneId}`;
        this.activeJobs.add(jobKey);

        // Process job asynchronously in background
        this.runClipJob(projectId, sceneId).finally(() => {
          this.activeJobs.delete(jobKey);
          this.processQueue();
        });
      }
    } finally {
      this.isProcessing = false;
    }
  }

  /**
   * Runs an individual clip generation job.
   */
  private static async runClipJob(projectId: string, sceneId: string) {
    const project = db.getProjectById(projectId);
    if (!project || this.cancelledProjects.has(projectId)) return;

    let targetScene: Scene | null = null;
    let sceneIndex = 0;
    for (const chapter of project.chapters) {
      for (const sc of chapter.scenes) {
        sceneIndex++;
        if (sc.sceneId === sceneId) {
          targetScene = sc;
          break;
        }
      }
      if (targetScene) break;
    }

    if (!targetScene || targetScene.status === 'COMPLETED') return;

    // Mark scene as generating
    targetScene.status = 'GENERATING';
    project.currentClipIndex = targetScene.sceneIndex;
    project.currentStatusMessage = `Generating clip ${targetScene.sceneIndex} of ${project.totalClips}...`;
    db.saveProject(project);

    try {
      const result = await VideoGenerationService.generateVideoClip({
        scene: targetScene,
        modelId: project.model,
        aspectRatio: project.aspectRatio,
        resolution: project.resolution,
        audioEnabled: project.audioEnabled,
        onProgress: (statusMsg) => {
          const p = db.getProjectById(projectId);
          if (p && !this.cancelledProjects.has(projectId)) {
            p.currentStatusMessage = `Clip ${targetScene!.sceneIndex}/${project.totalClips}: ${statusMsg}`;
            db.saveProject(p);
          }
        },
      });

      const updatedProject = db.getProjectById(projectId);
      if (!updatedProject || this.cancelledProjects.has(projectId)) return;

      if (result.success && result.clipUrl && result.clipPath) {
        db.updateScene(projectId, sceneId, {
          status: 'COMPLETED',
          clipUrl: result.clipUrl,
          clipPath: result.clipPath,
          completedAt: new Date().toISOString(),
          error: undefined,
        });
      } else {
        db.updateScene(projectId, sceneId, {
          status: 'FAILED',
          error: result.error || 'Generation failed',
          retryCount: (targetScene.retryCount || 0) + 1,
        });
      }

      // Check if all clips are now complete or failed
      this.checkProjectCompletion(projectId);
    } catch (err: any) {
      db.updateScene(projectId, sceneId, {
        status: 'FAILED',
        error: err?.message || 'Unexpected worker error',
      });
      this.checkProjectCompletion(projectId);
    }
  }

  /**
   * Checks whether all scenes have completed, triggers FFmpeg assembly if so.
   */
  private static async checkProjectCompletion(projectId: string) {
    const project = db.getProjectById(projectId);
    if (!project || project.status === 'CANCELLED') return;

    let pendingCount = 0;
    let completedCount = 0;
    let failedCount = 0;
    let totalCount = 0;

    for (const chapter of project.chapters) {
      for (const scene of chapter.scenes) {
        totalCount++;
        if (scene.status === 'COMPLETED') completedCount++;
        else if (scene.status === 'FAILED') failedCount++;
        else pendingCount++;
      }
    }

    project.totalClips = totalCount;
    project.completedClips = completedCount;
    project.failedClips = failedCount;
    project.progress = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

    // If still have pending scenes or queue items, continue
    if (pendingCount > 0) {
      db.saveProject(project);
      return;
    }

    // If some clips failed and none pending
    if (failedCount > 0) {
      project.status = 'FAILED';
      project.currentStatusMessage = `${failedCount} clip${failedCount > 1 ? 's' : ''} failed to generate. Click "Retry Failed Clips" to continue.`;
      project.error = `${failedCount} of ${totalCount} clips encountered errors.`;
      db.saveProject(project);
      return;
    }

    // All clips completed! Begin Assembly
    project.status = 'ASSEMBLING';
    project.currentStatusMessage = 'All clips generated! Assembling final MP4 video with FFmpeg...';
    db.saveProject(project);

    try {
      const assemblyResult = await VideoAssemblyService.assembleProject(project);

      const finalProject = db.getProjectById(projectId);
      if (!finalProject) return;

      if (assemblyResult.success && assemblyResult.finalVideoUrl) {
        finalProject.status = 'COMPLETED';
        finalProject.finalVideoUrl = assemblyResult.finalVideoUrl;
        finalProject.finalVideoPath = assemblyResult.finalVideoPath;
        finalProject.currentStatusMessage = 'Your video is ready!';
        finalProject.progress = 100;
        db.saveProject(finalProject);
      } else {
        finalProject.status = 'FAILED';
        finalProject.currentStatusMessage = `Assembly failed: ${assemblyResult.error}`;
        finalProject.error = assemblyResult.error;
        db.saveProject(finalProject);
      }
    } catch (err: any) {
      const finalProject = db.getProjectById(projectId);
      if (finalProject) {
        finalProject.status = 'FAILED';
        finalProject.error = `Video assembly exception: ${err?.message || 'Unknown error'}`;
        finalProject.currentStatusMessage = 'Video assembly failed. Check system logs.';
        db.saveProject(finalProject);
      }
    }
  }

  static getActiveJobsCount(): number {
    return this.activeJobs.size;
  }
}
