import fs from 'fs';
import path from 'path';
import { spawn } from 'child_process';
import { StorageService } from './storageService';
import { Project, Scene } from '../../src/types';

export class VideoAssemblyService {
  /**
   * Checks if ffmpeg is available on the system
   */
  static async checkFfmpeg(): Promise<boolean> {
    return new Promise((resolve) => {
      const child = spawn('ffmpeg', ['-version']);
      child.on('error', () => resolve(false));
      child.on('close', (code) => resolve(code === 0));
    });
  }

  /**
   * Assembles all completed scene clips for a project into a cohesive final MP4 video.
   */
  static async assembleProject(project: Project): Promise<{
    success: boolean;
    finalVideoUrl?: string;
    finalVideoPath?: string;
    error?: string;
  }> {
    // 1. Gather all scenes in order
    const orderedScenes: Scene[] = [];
    for (const chapter of project.chapters) {
      for (const scene of chapter.scenes) {
        orderedScenes.push(scene);
      }
    }

    if (orderedScenes.length === 0) {
      return { success: false, error: 'Project has no scenes to assemble.' };
    }

    // 2. Validate that completed clips exist
    const validClipPaths: string[] = [];
    for (const scene of orderedScenes) {
      if (scene.status !== 'COMPLETED' || !scene.clipPath) {
        return {
          success: false,
          error: `Cannot assemble: Scene "${scene.title}" (${scene.sceneId}) is not completed.`,
        };
      }
      if (!fs.existsSync(scene.clipPath)) {
        return {
          success: false,
          error: `Clip file missing on disk for scene "${scene.title}": ${scene.clipPath}`,
        };
      }
      validClipPaths.push(scene.clipPath);
    }

    // 3. Prepare temporary concat list
    const tempDir = path.resolve(process.cwd(), 'data', 'temp');
    if (!fs.existsSync(tempDir)) {
      fs.mkdirSync(tempDir, { recursive: true });
    }

    const listFilePath = path.join(tempDir, `concat_${project.id}_${Date.now()}.txt`);
    const outputFilePath = path.join(StorageService.getFinalDir(), `${project.id}.mp4`);

    // Format list for ffmpeg concat demuxer
    const listContent = validClipPaths
      .map((p) => `file '${p.replace(/'/g, "'\\''")}'`)
      .join('\n');
    fs.writeFileSync(listFilePath, listContent, 'utf-8');

    // 4. Run FFmpeg concatenation with normalization
    const ffmpegAvailable = await this.checkFfmpeg();

    if (!ffmpegAvailable) {
      // Fallback if ffmpeg is somehow not accessible
      fs.unlinkSync(listFilePath);
      return { success: false, error: 'FFmpeg is not installed or available on this system.' };
    }

    try {
      await new Promise<void>((resolve, reject) => {
        // Fast concat with copy first, fallback to re-encode if timestamps differ
        const ffmpegArgs = [
          '-y',
          '-f',
          'concat',
          '-safe',
          '0',
          '-i',
          listFilePath,
          '-c',
          'copy',
          outputFilePath,
        ];

        const proc = spawn('ffmpeg', ffmpegArgs);
        let errorOutput = '';

        proc.stderr.on('data', (data) => {
          errorOutput += data.toString();
        });

        proc.on('close', (code) => {
          if (code === 0 && fs.existsSync(outputFilePath) && fs.statSync(outputFilePath).size > 0) {
            resolve();
          } else {
            console.warn('FFmpeg copy concat failed, attempting full normalize re-encode...', errorOutput);
            // Re-encode attempt to normalize frame rates, aspect ratio, audio
            const targetWidth = project.aspectRatio === '9:16' ? 720 : 1280;
            const targetHeight = project.aspectRatio === '9:16' ? 1280 : 720;

            const reencodeArgs = [
              '-y',
              '-f',
              'concat',
              '-safe',
              '0',
              '-i',
              listFilePath,
              '-vf',
              `scale=${targetWidth}:${targetHeight}:force_original_aspect_ratio=decrease,pad=${targetWidth}:${targetHeight}:(ow-iw)/2:(oh-ih)/2,format=yuv420p`,
              '-c:v',
              'libx264',
              '-preset',
              'ultrafast',
              '-r',
              '30',
              '-c:a',
              'aac',
              '-ar',
              '44100',
              '-b:a',
              '128k',
              outputFilePath,
            ];

            const reencodeProc = spawn('ffmpeg', reencodeArgs);
            let reencodeErr = '';
            reencodeProc.stderr.on('data', (d) => {
              reencodeErr += d.toString();
            });

            reencodeProc.on('close', (reCode) => {
              if (reCode === 0 && fs.existsSync(outputFilePath) && fs.statSync(outputFilePath).size > 0) {
                resolve();
              } else {
                reject(new Error(`FFmpeg re-encode failed (code ${reCode}): ${reencodeErr}`));
              }
            });

            reencodeProc.on('error', (err) => reject(err));
          }
        });

        proc.on('error', (err) => reject(err));
      });

      // Cleanup temp list file
      if (fs.existsSync(listFilePath)) {
        fs.unlinkSync(listFilePath);
      }

      return {
        success: true,
        finalVideoUrl: `/api/storage/videos/${project.id}.mp4`,
        finalVideoPath: outputFilePath,
      };
    } catch (err: any) {
      if (fs.existsSync(listFilePath)) {
        fs.unlinkSync(listFilePath);
      }
      console.error('Video assembly failed:', err);
      return {
        success: false,
        error: `Assembly failure: ${err?.message || 'Unknown video processing error'}`,
      };
    }
  }
}
