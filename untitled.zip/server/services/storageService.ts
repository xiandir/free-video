import fs from 'fs';
import path from 'path';

const STORAGE_ROOT = path.resolve(process.cwd(), 'data', 'storage');
const CLIPS_DIR = path.join(STORAGE_ROOT, 'clips');
const FINAL_DIR = path.join(STORAGE_ROOT, 'final');
const THUMBNAILS_DIR = path.join(STORAGE_ROOT, 'thumbnails');

export class StorageService {
  static init() {
    [STORAGE_ROOT, CLIPS_DIR, FINAL_DIR, THUMBNAILS_DIR].forEach(dir => {
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
    });
  }

  static getClipsDir(): string {
    this.init();
    return CLIPS_DIR;
  }

  static getFinalDir(): string {
    this.init();
    return FINAL_DIR;
  }

  static getThumbnailsDir(): string {
    this.init();
    return THUMBNAILS_DIR;
  }

  static async uploadClip(clipId: string, buffer: Buffer): Promise<{ filePath: string; url: string }> {
    this.init();
    const fileName = `${clipId}.mp4`;
    const filePath = path.join(CLIPS_DIR, fileName);
    fs.writeFileSync(filePath, buffer);
    return {
      filePath,
      url: `/api/storage/clips/${fileName}`,
    };
  }

  static getClip(clipId: string): { filePath: string; exists: boolean } {
    this.init();
    const fileName = clipId.endsWith('.mp4') ? clipId : `${clipId}.mp4`;
    const filePath = path.join(CLIPS_DIR, fileName);
    return {
      filePath,
      exists: fs.existsSync(filePath),
    };
  }

  static deleteClip(clipId: string): boolean {
    const { filePath, exists } = this.getClip(clipId);
    if (exists) {
      try {
        fs.unlinkSync(filePath);
        return true;
      } catch (err) {
        console.error(`Failed to delete clip ${clipId}:`, err);
        return false;
      }
    }
    return false;
  }

  static async uploadFinalVideo(projectId: string, buffer: Buffer): Promise<{ filePath: string; url: string }> {
    this.init();
    const fileName = `${projectId}.mp4`;
    const filePath = path.join(FINAL_DIR, fileName);
    fs.writeFileSync(filePath, buffer);
    return {
      filePath,
      url: `/api/storage/videos/${fileName}`,
    };
  }

  static getFinalVideo(projectId: string): { filePath: string; exists: boolean } {
    this.init();
    const fileName = projectId.endsWith('.mp4') ? projectId : `${projectId}.mp4`;
    const filePath = path.join(FINAL_DIR, fileName);
    return {
      filePath,
      exists: fs.existsSync(filePath),
    };
  }

  static deleteFinalVideo(projectId: string): boolean {
    const { filePath, exists } = this.getFinalVideo(projectId);
    if (exists) {
      try {
        fs.unlinkSync(filePath);
        return true;
      } catch (err) {
        console.error(`Failed to delete final video ${projectId}:`, err);
        return false;
      }
    }
    return false;
  }

  static getStorageStats() {
    this.init();
    let clipCount = 0;
    let finalCount = 0;
    let totalBytes = 0;

    const countDir = (dir: string) => {
      if (fs.existsSync(dir)) {
        const files = fs.readdirSync(dir);
        for (const file of files) {
          const stats = fs.statSync(path.join(dir, file));
          totalBytes += stats.size;
        }
        return files.length;
      }
      return 0;
    };

    clipCount = countDir(CLIPS_DIR);
    finalCount = countDir(FINAL_DIR);

    return {
      clipCount,
      finalCount,
      totalSizeMb: Math.round((totalBytes / (1024 * 1024)) * 100) / 100,
    };
  }
}
