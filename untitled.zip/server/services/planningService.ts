import { getAiClient } from './geminiClient';
import { ModelCapabilityService } from '../../src/config/modelCapabilities';
import { ContinuityService } from './continuityService';
import { Chapter, ContinuityState, Project, Scene } from '../../src/types';

export class PlanningService {
  /**
   * Enhances a user prompt using Gemini 3.8 Flash.
   */
  static async enhancePrompt(prompt: string, style?: string): Promise<string> {
    const ai = getAiClient();
    if (!ai) {
      // If AI key is not configured, generate a deterministic high-fidelity expansion
      return `${prompt}. Cinematic 8k composition, professional volumetric lighting, smooth camera tracking shot, shallow depth of field, photorealistic textures, atmospheric environmental details, rich color grading.`;
    }

    try {
      const generatePromise = ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: `You are an expert AI cinematographer and video prompt director for Veo video generation.
Enhance the following video prompt while strictly preserving the user's core intent and subject.
Include concrete details for:
- Subject (detailed physical attributes, expression)
- Environment (world, architecture, setting, scale)
- Action (clear, natural, fluid movement)
- Camera (focal length, angle, movement like dolly, pan, or crane)
- Lighting (source, mood, reflections, shadows)
- Composition (framing, rule of thirds, depth)
- Visual Style (${style || 'cinematic photorealistic'})
- Atmosphere (air, haze, moisture, particles)
- Audio instructions (realistic ambient soundscape and Foley)

Do NOT output conversational preamble or bullet points. Provide ONE cohesive, richly detailed paragraph ready for video generation.

Original prompt: "${prompt}"`,
      });

      const timeoutPromise = new Promise<never>((_, reject) =>
        setTimeout(() => reject(new Error('Gemini enhancement timeout')), 6000)
      );

      const response = await Promise.race([generatePromise, timeoutPromise]);
      return response.text?.trim() || prompt;
    } catch (err) {
      console.warn('Gemini prompt enhancement fallback:', err);
      return `${prompt}. Cinematic 8k composition, master lighting, smooth camera tracking shot, atmospheric environmental depth, photorealistic textures, rich cinematic color grade.`;
    }
  }

  /**
   * Generates a comprehensive multi-chapter, multi-scene video plan matching the requested duration
   * and the active model's clip duration.
   */
  static async createVideoPlan(params: {
    prompt: string;
    enhancedPrompt?: string;
    durationSeconds: number;
    modelId: string;
    style: string;
    aspectRatio: string;
    resolution: string;
    audioEnabled: boolean;
  }): Promise<{
    title: string;
    description: string;
    chapters: Chapter[];
    continuity: ContinuityState;
    totalClips: number;
  }> {
    const { prompt, enhancedPrompt, durationSeconds, modelId, style, audioEnabled } = params;

    // Calculate dynamic clip requirement
    const { totalClips, clipDuration } = ModelCapabilityService.calculateClips(modelId, durationSeconds);
    const continuity = ContinuityService.extractContinuity(enhancedPrompt || prompt, style);

    // Determine how many chapters make sense for this duration:
    // e.g. 10s-30s: 1 chapter (2-4 clips)
    // 1m-5m: 2-3 chapters
    // 10m-30m: 4-6 chapters
    // 60m-120m: 6-12 chapters
    let numChapters = 1;
    if (totalClips > 60) numChapters = 8;
    else if (totalClips > 20) numChapters = 5;
    else if (totalClips > 8) numChapters = 3;
    else if (totalClips > 3) numChapters = 2;

    const clipsPerChapter = Math.ceil(totalClips / numChapters);

    const ai = getAiClient();
    let generatedPlan: any = null;

    if (ai) {
      try {
        const planningPrompt = `You are an elite Hollywood director, documentary showrunner, and long-form AI video architect for Veo.
Create a structured production plan for a video project.

Project Requirements:
- Core Prompt: "${prompt}"
- Enhanced Prompt: "${enhancedPrompt || prompt}"
- Total Project Duration: ${durationSeconds} seconds (${Math.round(durationSeconds / 60)} minutes)
- Total Video Clips Needed: ${totalClips} clips (${clipDuration} seconds per clip)
- Planned Chapters: ${numChapters} chapters (~${clipsPerChapter} clips per chapter)
- Visual Style: ${style}
- Audio: ${audioEnabled ? 'Native synchronized audio with natural ambience and Foley' : 'Silent / Ambient track'}

Format your entire response as valid JSON with no markdown backticks, matching this exact JSON structure:
{
  "title": "Creative project title",
  "description": "Engaging 2-sentence synopsis of the overall project narrative",
  "chapters": [
    {
      "title": "Chapter title",
      "description": "Chapter narrative arc",
      "scenes": [
        {
          "title": "Scene title",
          "prompt": "Vivid shot description focusing on subject, motion, environment, camera, and lighting",
          "cameraMovement": "e.g. Low-angle slow tracking forward",
          "audioInstructions": "Ambient sounds, engine notes, or Foley"
        }
      ]
    }
  ]
}

Ensure the total number of scenes across all chapters equals exactly ${totalClips}.`;

        const planPromise = ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: planningPrompt,
          config: {
            responseMimeType: 'application/json',
          },
        });

        const planTimeout = new Promise<never>((_, reject) =>
          setTimeout(() => reject(new Error('Gemini plan generation timeout')), 7000)
        );

        const response = await Promise.race([planPromise, planTimeout]);

        if (response.text) {
          const cleanedText = response.text.replace(/```json/g, '').replace(/```/g, '').trim();
          generatedPlan = JSON.parse(cleanedText);
        }
      } catch (err) {
        console.warn('Gemini video plan generation fallback:', err);
      }
    }

    // Build or normalize the structured Chapters and Scenes
    const chapters: Chapter[] = [];
    let currentClipCount = 0;

    const defaultTitle = prompt.length > 50 ? `${prompt.slice(0, 47)}...` : prompt;
    const projectTitle = generatedPlan?.title || `Cinematic: ${defaultTitle}`;
    const projectDescription = generatedPlan?.description || `A cinematic ${style} project exploring: ${prompt}`;

    if (generatedPlan?.chapters && Array.isArray(generatedPlan.chapters) && generatedPlan.chapters.length > 0) {
      for (let cIdx = 0; cIdx < generatedPlan.chapters.length; cIdx++) {
        const rawChap = generatedPlan.chapters[cIdx];
        const chapterId = `chap_${cIdx + 1}_${Date.now()}`;
        const scenes: Scene[] = [];

        if (Array.isArray(rawChap.scenes)) {
          for (const rawScene of rawChap.scenes) {
            if (currentClipCount >= totalClips) break;
            currentClipCount++;

            const sceneId = `sc_${currentClipCount}_${Date.now()}`;
            const previousScene = scenes.length > 0 ? scenes[scenes.length - 1] : null;

            const scenePrompt = rawScene.prompt || `Shot ${currentClipCount}: ${prompt}`;
            const contextAwarePrompt = ContinuityService.buildContextAwarePrompt(
              scenePrompt,
              previousScene,
              null,
              continuity,
              currentClipCount,
              totalClips
            );

            scenes.push({
              sceneId,
              chapterId,
              sceneIndex: currentClipCount,
              duration: clipDuration,
              title: rawScene.title || `Shot ${currentClipCount}`,
              prompt: scenePrompt,
              contextAwarePrompt,
              previousSceneContext: previousScene ? previousScene.title : undefined,
              cameraMovement: rawScene.cameraMovement || 'Smooth cinematic tracking',
              audioInstructions: rawScene.audioInstructions || (audioEnabled ? 'Natural environment audio' : undefined),
              visualContinuity: continuity.visualStyle,
              status: 'PENDING',
            });
          }
        }

        if (scenes.length > 0) {
          chapters.push({
            chapterId,
            chapterIndex: cIdx + 1,
            title: rawChap.title || `Chapter ${cIdx + 1}`,
            description: rawChap.description || `Narrative segment ${cIdx + 1}`,
            estimatedDuration: scenes.length * clipDuration,
            scenes,
          });
        }
        if (currentClipCount >= totalClips) break;
      }
    }

    // If AI didn't provide enough scenes (or in fallback mode), fill out all required clips up to totalClips
    while (currentClipCount < totalClips) {
      const chapterIdx = Math.floor(currentClipCount / clipsPerChapter) + 1;
      let chapter = chapters.find(c => c.chapterIndex === chapterIdx);

      if (!chapter) {
        const chapterId = `chap_${chapterIdx}_${Date.now()}`;
        chapter = {
          chapterId,
          chapterIndex: chapterIdx,
          title: `Chapter ${chapterIdx}: Progression`,
          description: `Progression and narrative development of the sequence.`,
          estimatedDuration: 0,
          scenes: [],
        };
        chapters.push(chapter);
      }

      currentClipCount++;
      const sceneId = `sc_${currentClipCount}_${Date.now()}`;
      const lastSceneInChapter = chapter.scenes.length > 0 ? chapter.scenes[chapter.scenes.length - 1] : null;

      const angleVariants = [
        'Wide establishing shot with expansive landscape view',
        'Close-up tracking motion with shallow depth of field',
        'Dynamic medium shot capturing detailed actions and speed',
        'Overhead aerial drone shot gliding smoothly forward',
        'Low-angle dramatic heroic angle with atmospheric rim lighting',
        'Pivoting cinematic reveal shot around the focal subject',
      ];
      const selectedAngle = angleVariants[(currentClipCount - 1) % angleVariants.length];

      const scenePrompt = `${selectedAngle}. ${prompt}. Detailed textures, realistic motion, 8K resolution.`;
      const contextAwarePrompt = ContinuityService.buildContextAwarePrompt(
        scenePrompt,
        lastSceneInChapter,
        null,
        continuity,
        currentClipCount,
        totalClips
      );

      const newScene: Scene = {
        sceneId,
        chapterId: chapter.chapterId,
        sceneIndex: currentClipCount,
        duration: clipDuration,
        title: `Scene ${currentClipCount}: ${selectedAngle.split('.')[0]}`,
        prompt: scenePrompt,
        contextAwarePrompt,
        previousSceneContext: lastSceneInChapter ? lastSceneInChapter.title : undefined,
        cameraMovement: selectedAngle.split('.')[0],
        audioInstructions: audioEnabled ? 'Synchronized ambient acoustics and movement Foley' : undefined,
        visualContinuity: continuity.visualStyle,
        status: 'PENDING',
      };

      chapter.scenes.push(newScene);
      chapter.estimatedDuration += clipDuration;
    }

    return {
      title: projectTitle,
      description: projectDescription,
      chapters,
      continuity,
      totalClips,
    };
  }
}
