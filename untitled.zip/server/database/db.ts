import fs from 'fs';
import path from 'path';
import { Project, Scene } from '../../src/types';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

interface DatabaseSchema {
  projects: Record<string, Project>;
}

class Database {
  private schema: DatabaseSchema = {
    projects: {},
  };
  private isLoaded = false;

  private ensureDirectory() {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
  }

  private load() {
    this.ensureDirectory();
    if (!this.isLoaded) {
      if (fs.existsSync(DB_FILE)) {
        try {
          const content = fs.readFileSync(DB_FILE, 'utf-8');
          this.schema = JSON.parse(content);
        } catch (e) {
          console.error('Failed to parse database file, initializing empty schema', e);
          this.schema = { projects: {} };
        }
      } else {
        this.save();
      }
      this.isLoaded = true;
    }
  }

  private save() {
    this.ensureDirectory();
    try {
      fs.writeFileSync(DB_FILE, JSON.stringify(this.schema, null, 2), 'utf-8');
    } catch (e) {
      console.error('Failed to write database file', e);
    }
  }

  getProjects(): Project[] {
    this.load();
    return Object.values(this.schema.projects).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  getProjectById(id: string): Project | null {
    this.load();
    return this.schema.projects[id] || null;
  }

  saveProject(project: Project): Project {
    this.load();
    project.updatedAt = new Date().toISOString();
    this.schema.projects[project.id] = project;
    this.save();
    return project;
  }

  deleteProject(id: string): boolean {
    this.load();
    if (this.schema.projects[id]) {
      delete this.schema.projects[id];
      this.save();
      return true;
    }
    return false;
  }

  updateScene(projectId: string, sceneId: string, updates: Partial<Scene>): Scene | null {
    this.load();
    const project = this.schema.projects[projectId];
    if (!project) return null;

    let targetScene: Scene | null = null;
    for (const chapter of project.chapters) {
      for (let i = 0; i < chapter.scenes.length; i++) {
        if (chapter.scenes[i].sceneId === sceneId) {
          chapter.scenes[i] = { ...chapter.scenes[i], ...updates };
          targetScene = chapter.scenes[i];
          break;
        }
      }
      if (targetScene) break;
    }

    if (targetScene) {
      // Recalculate project totals
      let completed = 0;
      let failed = 0;
      let total = 0;
      for (const chapter of project.chapters) {
        for (const sc of chapter.scenes) {
          total++;
          if (sc.status === 'COMPLETED') completed++;
          if (sc.status === 'FAILED') failed++;
        }
      }
      project.totalClips = total;
      project.completedClips = completed;
      project.failedClips = failed;
      project.progress = total > 0 ? Math.round((completed / total) * 100) : 0;
      this.saveProject(project);
    }

    return targetScene;
  }
}

export const db = new Database();
