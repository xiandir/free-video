import { ModelCapability, AspectRatio, Resolution } from '../types';

export const MODEL_CAPABILITIES: Record<string, ModelCapability> = {
  'veo-3.1-generate-preview': {
    id: 'veo-3.1-generate-preview',
    name: 'Veo 3.1 Cinema (Flagship)',
    description: 'High-definition video generation supporting 4K, native audio, video extension, and visual reference frames.',
    supportedDurations: [4, 6, 8],
    defaultDuration: 8,
    supportedAspectRatios: ['16:9', '9:16'],
    supportedResolutions: ['720p', '1080p', '4k'],
    supportsExtension: true,
    supportsReferenceImages: true,
    supportsAudio: true,
    requiresPaidKey: true,
    resolutionRequirements: {
      '4k': { minDuration: 4, maxDuration: 8, aspectRatio: '16:9' },
      '1080p': { minDuration: 4, maxDuration: 8 },
      '720p': { minDuration: 4, maxDuration: 8 },
    },
  },
  'veo-3.1-lite-generate-preview': {
    id: 'veo-3.1-lite-generate-preview',
    name: 'Veo 3.1 Lite (Fast)',
    description: 'High-throughput video generation optimized for rapid rendering up to 1080p.',
    supportedDurations: [4, 6, 8],
    defaultDuration: 8,
    supportedAspectRatios: ['16:9', '9:16'],
    supportedResolutions: ['720p', '1080p'],
    supportsExtension: false,
    supportsReferenceImages: false,
    supportsAudio: true,
    requiresPaidKey: true,
    resolutionRequirements: {
      '1080p': { minDuration: 4, maxDuration: 8 },
      '720p': { minDuration: 4, maxDuration: 8 },
      '4k': { minDuration: 0, maxDuration: 0 }, // Not supported
    },
  },
};

export const DEFAULT_MODEL_ID = 'veo-3.1-generate-preview';
export const MAX_PROJECT_DURATION_SECONDS = 7200; // 120 minutes (2 hours)

export class ModelCapabilityService {
  static getAvailableModels(): ModelCapability[] {
    return Object.values(MODEL_CAPABILITIES);
  }

  static getModelCapabilities(modelId: string): ModelCapability {
    return MODEL_CAPABILITIES[modelId] || MODEL_CAPABILITIES[DEFAULT_MODEL_ID];
  }

  static getSupportedDurations(modelId: string): number[] {
    return this.getModelCapabilities(modelId).supportedDurations;
  }

  static getMaximumClipDuration(modelId: string): number {
    const durations = this.getSupportedDurations(modelId);
    return Math.max(...durations);
  }

  static getSupportedAspectRatios(modelId: string): AspectRatio[] {
    return this.getModelCapabilities(modelId).supportedAspectRatios;
  }

  static getSupportedResolutions(modelId: string): Resolution[] {
    return this.getModelCapabilities(modelId).supportedResolutions;
  }

  static supportsExtension(modelId: string): boolean {
    return this.getModelCapabilities(modelId).supportsExtension;
  }

  static supportsReferenceImages(modelId: string): boolean {
    return this.getModelCapabilities(modelId).supportsReferenceImages;
  }

  static supportsAudio(modelId: string): boolean {
    return this.getModelCapabilities(modelId).supportsAudio;
  }

  /**
   * Calculates required number of clips dynamically based on requested duration
   * and the active model's clip duration.
   */
  static calculateClips(modelId: string, durationSeconds: number, preferredClipDuration?: number): {
    totalClips: number;
    clipDuration: number;
    totalDurationSeconds: number;
    isOverLimit: boolean;
  } {
    const cappedDuration = Math.min(Math.max(1, durationSeconds), MAX_PROJECT_DURATION_SECONDS);
    const model = this.getModelCapabilities(modelId);
    const clipDuration = preferredClipDuration && model.supportedDurations.includes(preferredClipDuration)
      ? preferredClipDuration
      : model.defaultDuration;

    const totalClips = Math.ceil(cappedDuration / clipDuration);

    return {
      totalClips,
      clipDuration,
      totalDurationSeconds: cappedDuration,
      isOverLimit: durationSeconds > MAX_PROJECT_DURATION_SECONDS,
    };
  }

  /**
   * Validates if a resolution/aspectRatio combination is supported by the model
   */
  static validateConfiguration(
    modelId: string,
    aspectRatio: AspectRatio,
    resolution: Resolution,
    clipDuration: number
  ): { valid: boolean; reason?: string } {
    const model = this.getModelCapabilities(modelId);

    if (!model.supportedAspectRatios.includes(aspectRatio)) {
      return { valid: false, reason: `Aspect ratio ${aspectRatio} is not supported by ${model.name}.` };
    }

    if (!model.supportedResolutions.includes(resolution)) {
      return { valid: false, reason: `Resolution ${resolution} is not supported by ${model.name}.` };
    }

    if (!model.supportedDurations.includes(clipDuration)) {
      return { valid: false, reason: `Clip duration ${clipDuration}s is not supported by ${model.name}. Valid options: ${model.supportedDurations.join(', ')}s.` };
    }

    return { valid: true };
  }
}
