import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { VideoPlayerModal } from './components/VideoPlayerModal';
import { DashboardPage } from './pages/DashboardPage';
import { CreateVideoPage } from './pages/CreateVideoPage';
import { ProjectDetailPage } from './pages/ProjectDetailPage';
import { MyVideosPage } from './pages/MyVideosPage';
import { ProjectsPage } from './pages/ProjectsPage';
import { TemplatesPage } from './pages/TemplatesPage';
import { SettingsPage } from './pages/SettingsPage';
import { Project, SystemStatus } from './types';
import { ApiService } from './services/api';
import { TEMPLATES } from './data/templates';
import { LayoutDashboard, Video, Film, FolderKanban, Sparkles } from 'lucide-react';

export default function App() {
  const [currentTab, setCurrentTab] = useState<string>('dashboard');
  const [activeProjectId, setActiveProjectId] = useState<string | null>(null);
  const [projects, setProjects] = useState<Project[]>([]);
  const [systemStatus, setSystemStatus] = useState<SystemStatus | null>(null);

  // Template prefill state for Create Video page
  const [createPrefill, setCreatePrefill] = useState<{
    prompt?: string;
    duration?: number;
    style?: string;
    model?: string;
    aspectRatio?: '16:9' | '9:16';
    resolution?: '720p' | '1080p' | '4k';
  }>({});

  // Video preview modal state
  const [previewVideo, setPreviewVideo] = useState<{
    url: string;
    title: string;
    duration?: number;
    resolution?: string;
    aspectRatio?: string;
  } | null>(null);

  // Load initial data
  const loadData = async () => {
    try {
      const [status, projList] = await Promise.all([
        ApiService.getSystemStatus().catch(() => null),
        ApiService.getProjects().catch(() => []),
      ]);
      if (status) setSystemStatus(status);
      setProjects(projList);
    } catch (err) {
      console.error('Error loading initial app data:', err);
    }
  };

  useEffect(() => {
    loadData();
    const interval = setInterval(loadData, 10000); // Poll list every 10 seconds
    return () => clearInterval(interval);
  }, []);

  const handleNavigate = (tab: string, projectId?: string) => {
    if (projectId) {
      setActiveProjectId(projectId);
      setCurrentTab('project-detail');
    } else {
      setCurrentTab(tab);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectTemplate = (templateId: string) => {
    const template = TEMPLATES.find((t) => t.id === templateId);
    if (template) {
      setCreatePrefill({
        prompt: template.prompt,
        duration: template.defaultDuration,
        style: template.style,
        model: template.suggestedModel,
        aspectRatio: template.aspectRatio,
        resolution: template.resolution,
      });
      setCurrentTab('create');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleProjectCreated = (newProject: Project) => {
    setProjects((prev) => [newProject, ...prev.filter((p) => p.id !== newProject.id)]);
    setActiveProjectId(newProject.id);
    setCurrentTab('project-detail');
  };

  const handlePreviewVideo = (url: string, title: string) => {
    setPreviewVideo({ url, title });
  };

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col font-sans selection:bg-cyan-500/20 selection:text-cyan-300">
      {/* Top Navbar */}
      <Navbar currentTab={currentTab} onNavigate={handleNavigate} systemStatus={systemStatus} />

      {/* Main Layout Area */}
      <div className="flex-1 flex max-w-7xl w-full mx-auto">
        {/* Desktop Sidebar */}
        <Sidebar currentTab={currentTab} onNavigate={handleNavigate} systemStatus={systemStatus} />

        {/* Page Content Viewport */}
        <main className="flex-1 min-w-0 p-4 sm:p-6 lg:p-8">
          {currentTab === 'dashboard' && (
            <DashboardPage
              projects={projects}
              systemStatus={systemStatus}
              onNavigate={handleNavigate}
              onSelectTemplate={handleSelectTemplate}
              onPreviewVideo={handlePreviewVideo}
            />
          )}

          {currentTab === 'create' && (
            <CreateVideoPage
              systemStatus={systemStatus}
              initialPrompt={createPrefill.prompt || ''}
              initialDuration={createPrefill.duration || 60}
              initialStyle={createPrefill.style || 'Cinematic'}
              initialModel={createPrefill.model || 'veo-3.1-generate-preview'}
              initialAspectRatio={createPrefill.aspectRatio || '16:9'}
              initialResolution={createPrefill.resolution || '720p'}
              onProjectCreated={handleProjectCreated}
            />
          )}

          {currentTab === 'project-detail' && activeProjectId && (
            <ProjectDetailPage
              projectId={activeProjectId}
              onNavigate={handleNavigate}
              onPreviewVideo={handlePreviewVideo}
            />
          )}

          {currentTab === 'my-videos' && (
            <MyVideosPage
              projects={projects}
              onNavigate={handleNavigate}
              onPreviewVideo={handlePreviewVideo}
              onRefresh={loadData}
            />
          )}

          {currentTab === 'projects' && (
            <ProjectsPage projects={projects} onNavigate={handleNavigate} onRefresh={loadData} />
          )}

          {currentTab === 'templates' && (
            <TemplatesPage onSelectTemplate={handleSelectTemplate} />
          )}

          {currentTab === 'settings' && (
            <SettingsPage systemStatus={systemStatus} onRefreshStatus={loadData} />
          )}
        </main>
      </div>

      {/* Mobile Bottom Navigation Bar (Fixed for quick thumb access on mobile) */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-neutral-950/95 backdrop-blur-lg border-t border-neutral-800 px-2 py-1.5 flex items-center justify-around">
        <button
          onClick={() => handleNavigate('dashboard')}
          className={`flex flex-col items-center gap-1 p-1 text-[10px] font-medium ${
            currentTab === 'dashboard' ? 'text-cyan-400' : 'text-neutral-400'
          }`}
        >
          <LayoutDashboard className="w-4 h-4" />
          <span>Dashboard</span>
        </button>
        <button
          onClick={() => handleNavigate('create')}
          className={`flex flex-col items-center gap-1 p-1 text-[10px] font-medium ${
            currentTab === 'create' ? 'text-cyan-400' : 'text-neutral-400'
          }`}
        >
          <Video className="w-4 h-4" />
          <span>Create</span>
        </button>
        <button
          onClick={() => handleNavigate('my-videos')}
          className={`flex flex-col items-center gap-1 p-1 text-[10px] font-medium ${
            currentTab === 'my-videos' ? 'text-cyan-400' : 'text-neutral-400'
          }`}
        >
          <Film className="w-4 h-4" />
          <span>Videos</span>
        </button>
        <button
          onClick={() => handleNavigate('projects')}
          className={`flex flex-col items-center gap-1 p-1 text-[10px] font-medium ${
            currentTab === 'projects' ? 'text-cyan-400' : 'text-neutral-400'
          }`}
        >
          <FolderKanban className="w-4 h-4" />
          <span>Projects</span>
        </button>
        <button
          onClick={() => handleNavigate('templates')}
          className={`flex flex-col items-center gap-1 p-1 text-[10px] font-medium ${
            currentTab === 'templates' ? 'text-cyan-400' : 'text-neutral-400'
          }`}
        >
          <Sparkles className="w-4 h-4" />
          <span>Templates</span>
        </button>
      </div>

      {/* Video Preview Modal */}
      {previewVideo && (
        <VideoPlayerModal
          isOpen={Boolean(previewVideo)}
          onClose={() => setPreviewVideo(null)}
          videoUrl={previewVideo.url}
          title={previewVideo.title}
          duration={previewVideo.duration}
          resolution={previewVideo.resolution}
          aspectRatio={previewVideo.aspectRatio}
        />
      )}
    </div>
  );
}
