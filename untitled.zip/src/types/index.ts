export type ProjectStatus =
  | 'DRAFT'
  | 'PLANNING'
  | 'QUEUED'
  | 'GENERATING'
  | 'ASSEMBLING'
  | 'COMPLETED'
  | 'FAILED'
  | 'CANCELLED';

export type SceneStatus = 'PENDING' | 'GENERATING' | 'COMPLETED' | 'FAILED';

export type AspectRatio = '16:9' | '9:16';
export type Resolution = '720p' | '1080p' | '4k';

export interface ModelCapability {
  id: string;
  name: string;
  description: string;
  supportedDurations: number[]; // e.g. [4, 6, 8]
  defaultDuration: number;
  supportedAspectRatios: AspectRatio[];
  supportedResolutions: Resolution[];
  supportsExtension: boolean;
  supportsReferenceImages: boolean;
  supportsAudio: boolean;
  requiresPaidKey: boolean;
  resolutionRequirements?: Record<Resolution, { minDuration?: number; maxDuration?: number; aspectRatio?: AspectRatio }>;
}

export interface Scene {
  sceneId: string;
  chapterId: string;
  sceneIndex: number;
  duration: number; // in seconds (e.g. 8)
  title: string;
  prompt: string;
  contextAwarePrompt: string;
  previousSceneContext?: string;
  nextSceneContext?: string;
  visualContinuity?: string;
  cameraMovement?: string;
  audioInstructions?: string;
  status: SceneStatus;
  clipUrl?: string;
  clipPath?: string;
  thumbnailUrl?: string;
  error?: string;
  retryCount?: number;
  operationName?: string;
  createdAt?: string;
  completedAt?: string;
}

export interface Chapter {
  chapterId: string;
  chapterIndex: number;
  title: string;
  description: string;
  estimatedDuration: number; // in seconds
  scenes: Scene[];
}

export interface ContinuityState {
  characters: string[];
  clothing: string;
  locations: string[];
  vehicles: string;
  objects: string[];
  architecture: string;
  lighting: string;
  weather: string;
  timeOfDay: string;
  colorPalette: string;
  cameraStyle: string;
  visualStyle: string;
}

export interface Project {
  id: string;
  userId?: string;
  title: string;
  description: string;
  prompt: string;
  enhancedPrompt?: string;
  requestedDuration: number; // in seconds (up to 7200s = 120m)
  model: string;
  aspectRatio: AspectRatio;
  resolution: Resolution;
  style: string;
  audioEnabled: boolean;
  audioInstructions?: string;
  status: ProjectStatus;
  totalClips: number;
  completedClips: number;
  failedClips: number;
  currentClipIndex: number;
  progress: number; // 0 - 100
  currentStatusMessage: string;
  chapters: Chapter[];
  continuity?: ContinuityState;
  finalVideoUrl?: string;
  finalVideoPath?: string;
  thumbnailUrl?: string;
  createdAt: string;
  updatedAt: string;
  error?: string;
}

export interface Template {
  id: string;
  title: string;
  tagline: string;
  description: string;
  category: string;
  defaultDuration: number; // in seconds
  suggestedModel: string;
  aspectRatio: AspectRatio;
  resolution: Resolution;
  style: string;
  prompt: string;
  coverImage: string;
  tags: string[];
}

export interface SystemStatus {
  apiConfigured: boolean;
  ffmpegAvailable: boolean;
  activeModel: string;
  totalProjects: number;
  totalClipsStored: number;
  storageStats?: {
    clipCount: number;
    finalCount: number;
    totalSizeMb: number;
  };
  workerActiveJobs: number;
}
