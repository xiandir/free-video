import React from 'react';
import { X, Download, Film, ExternalLink } from 'lucide-react';

interface VideoPlayerModalProps {
  isOpen: boolean;
  onClose: () => void;
  videoUrl: string;
  title: string;
  duration?: number;
  resolution?: string;
  aspectRatio?: string;
}

export const VideoPlayerModal: React.FC<VideoPlayerModalProps> = ({
  isOpen,
  onClose,
  videoUrl,
  title,
  duration,
  resolution,
  aspectRatio,
}) => {
  if (!isOpen) return null;

  const downloadFilename = videoUrl.split('/').pop() || 'video.mp4';
  const downloadUrl = `/api/storage/download/${downloadFilename}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/90 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-4xl rounded-2xl border border-neutral-800 bg-neutral-950 overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-neutral-800 bg-neutral-900/60">
          <div className="flex items-center gap-2.5 truncate">
            <Film className="w-4 h-4 text-cyan-400 shrink-0" />
            <h3 className="text-sm font-semibold text-white truncate">{title}</h3>
          </div>
          <div className="flex items-center gap-2">
            <a
              href={downloadUrl}
              download
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-neutral-800 hover:bg-neutral-700 rounded-lg transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download</span>
            </a>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Video Player */}
        <div className="relative flex-1 bg-black flex items-center justify-center min-h-[300px] max-h-[60vh] overflow-hidden">
          <video
            src={videoUrl}
            controls
            autoPlay
            playsInline
            className="w-full h-full object-contain"
          />
        </div>

        {/* Footer info */}
        <div className="flex items-center justify-between px-5 py-3 border-t border-neutral-800 bg-neutral-900/40 text-xs text-neutral-400">
          <div className="flex items-center gap-3">
            {duration && (
              <span className="font-mono tabular-nums">
                Duration: {duration >= 60 ? `${Math.round(duration / 60)} min` : `${duration}s`}
              </span>
            )}
            {resolution && <span>· Resolution: {resolution}</span>}
            {aspectRatio && <span>· Ratio: {aspectRatio}</span>}
          </div>
          <span className="text-[11px] text-neutral-500">FREEVIDAi Video Engine</span>
        </div>
      </div>
    </div>
  );
};
