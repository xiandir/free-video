import React from 'react';
import {
  LayoutDashboard,
  Video,
  Film,
  FolderKanban,
  Sparkles,
  Settings,
  Cpu,
  Clock,
} from 'lucide-react';
import { SystemStatus } from '../types';

interface SidebarProps {
  currentTab: string;
  onNavigate: (tab: string) => void;
  systemStatus: SystemStatus | null;
}

export const Sidebar: React.FC<SidebarProps> = ({ currentTab, onNavigate, systemStatus }) => {
  const items = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'create', label: 'Create Video', icon: Video },
    { id: 'my-videos', label: 'My Videos', icon: Film },
    { id: 'projects', label: 'Projects', icon: FolderKanban },
    { id: 'templates', label: 'Templates', icon: Sparkles },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  return (
    <aside className="hidden lg:flex flex-col w-64 border-r border-neutral-800 bg-neutral-950/70 p-4 shrink-0 justify-between h-[calc(100vh-4rem)] sticky top-16">
      <div className="space-y-6">
        <div>
          <p className="text-[11px] font-semibold text-neutral-500 uppercase tracking-wider px-3 mb-2">
            Navigation
          </p>
          <nav className="space-y-1">
            {items.map((item) => {
              const Icon = item.icon;
              const isActive = currentTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onNavigate(item.id)}
                  className={`w-full flex items-center gap-3 px-3 py-2 text-sm rounded-lg transition-colors cursor-pointer text-left ${
                    isActive
                      ? 'bg-neutral-800/80 text-white font-medium border border-neutral-700/50 shadow-sm'
                      : 'text-neutral-400 hover:text-white hover:bg-neutral-900/60'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-cyan-400' : 'text-neutral-400'}`} />
                  <span className="truncate">{item.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        {/* Long-Form Pipeline Metric Callout */}
        <div className="p-3.5 rounded-xl border border-neutral-800 bg-neutral-900/40 text-xs text-neutral-400 space-y-2">
          <div className="flex items-center justify-between text-neutral-300 font-medium">
            <span className="flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-cyan-400" />
              Long-Form Engine
            </span>
            <span className="font-mono text-cyan-400 tabular-nums">120m Max</span>
          </div>
          <p className="text-[11px] leading-relaxed text-neutral-400">
            Automated scene planning and multi-clip orchestration for cinematic video projects up to 2 hours.
          </p>
        </div>
      </div>

      {/* Model & System Status in Sidebar Footer */}
      <div className="pt-4 border-t border-neutral-800/80 space-y-2">
        <div className="flex items-center justify-between text-xs text-neutral-400">
          <span className="flex items-center gap-1.5 text-neutral-300">
            <Cpu className="w-3.5 h-3.5 text-cyan-400" />
            Veo 3.1 Cinema
          </span>
          <span className="font-mono text-[10px] text-neutral-400">v3.1</span>
        </div>
        <div className="flex items-center justify-between text-[11px] text-neutral-500 font-mono">
          <span>Active queue</span>
          <span className="text-neutral-300 tabular-nums">
            {systemStatus?.workerActiveJobs ?? 0} jobs
          </span>
        </div>
      </div>
    </aside>
  );
};
