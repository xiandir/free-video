import React from 'react';
import { AlertTriangle, Clock, Layers, Film, Sparkles, X } from 'lucide-react';
import { AspectRatio, Resolution } from '../types';

interface WorkloadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  durationSeconds: number;
  totalClips: number;
  clipDuration: number;
  modelName: string;
  resolution: Resolution;
  aspectRatio: AspectRatio;
  isStarting: boolean;
}

export const WorkloadModal: React.FC<WorkloadModalProps> = ({
  isOpen,
  onClose,
  onConfirm,
  durationSeconds,
  totalClips,
  clipDuration,
  modelName,
  resolution,
  aspectRatio,
  isStarting,
}) => {
  if (!isOpen) return null;

  const durationMinutes = Math.round(durationSeconds / 60);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-lg rounded-2xl border border-neutral-800 bg-neutral-900 p-6 shadow-2xl space-y-5">
        <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-white">Production Workload Confirmation</h3>
              <p className="text-xs text-neutral-400">Review orchestrator parameters before generation</p>
            </div>
          </div>
          <button
            onClick={onClose}
            disabled={isStarting}
            className="p-1 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="grid grid-cols-2 gap-3 text-xs">
          <div className="p-3 rounded-lg border border-neutral-800 bg-neutral-950/60 space-y-1">
            <span className="text-neutral-500">Requested Duration</span>
            <p className="font-semibold text-white text-sm font-mono tabular-nums">
              {durationSeconds >= 60 ? `${durationMinutes} min (${durationSeconds}s)` : `${durationSeconds} seconds`}
            </p>
          </div>

          <div className="p-3 rounded-lg border border-neutral-800 bg-neutral-950/60 space-y-1">
            <span className="text-neutral-500">Estimated AI Clips</span>
            <p className="font-semibold text-cyan-400 text-sm font-mono tabular-nums">
              {totalClips} clips ({clipDuration}s each)
            </p>
          </div>

          <div className="p-3 rounded-lg border border-neutral-800 bg-neutral-950/60 space-y-1">
            <span className="text-neutral-500">Active Model</span>
            <p className="font-semibold text-white truncate">{modelName}</p>
          </div>

          <div className="p-3 rounded-lg border border-neutral-800 bg-neutral-950/60 space-y-1">
            <span className="text-neutral-500">Format & Ratio</span>
            <p className="font-semibold text-white font-mono">
              {resolution} · {aspectRatio}
            </p>
          </div>
        </div>

        <div className="p-4 rounded-xl border border-amber-500/30 bg-amber-500/10 text-amber-300 text-xs leading-relaxed space-y-1.5">
          <div className="flex items-center gap-2 font-medium text-amber-200">
            <AlertTriangle className="w-4 h-4 shrink-0" />
            <span>High-Capacity Pipeline Notice</span>
          </div>
          <p>
            Long videos require many individual AI generations and may take significantly longer and consume
            substantially more generation capacity.
          </p>
          <p className="text-[11px] text-amber-300/80">
            Clips are individually saved and resumable. If any scene fails, you can retry it without restarting the
            project.
          </p>
        </div>

        <div className="flex items-center justify-end gap-3 pt-2">
          <button
            onClick={onClose}
            disabled={isStarting}
            className="px-4 py-2 text-xs font-medium text-neutral-300 hover:text-white bg-neutral-800 hover:bg-neutral-700 rounded-lg transition-colors cursor-pointer"
          >
            Cancel
          </button>
          <button
            onClick={onConfirm}
            disabled={isStarting}
            className="flex items-center gap-2 px-5 py-2 text-xs font-semibold text-neutral-950 bg-cyan-400 hover:bg-cyan-300 rounded-lg shadow-sm transition-all cursor-pointer disabled:opacity-50"
          >
            {isStarting ? (
              <>
                <div className="w-3.5 h-3.5 border-2 border-neutral-950 border-t-transparent rounded-full animate-spin" />
                <span>Initializing Pipeline...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Start Generation</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
