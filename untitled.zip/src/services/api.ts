import { Project, SystemStatus } from '../types';

export class ApiService {
  static async getSystemStatus(): Promise<SystemStatus> {
    const res = await fetch('/api/system/status');
    if (!res.ok) throw new Error('Failed to fetch system status');
    return res.json();
  }

  static async enhancePrompt(prompt: string, style?: string): Promise<string> {
    const res = await fetch('/api/ai/enhance-prompt', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt, style }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Failed to enhance prompt' }));
      throw new Error(err.error || 'Failed to enhance prompt');
    }
    const data = await res.json();
    return data.enhancedPrompt;
  }

  static async createProject(payload: {
    prompt: string;
    enhancedPrompt?: string;
    durationSeconds: number;
    modelId: string;
    style: string;
    aspectRatio: string;
    resolution: string;
    audioEnabled: boolean;
    audioInstructions?: string;
  }): Promise<Project> {
    const res = await fetch('/api/projects', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Failed to create project' }));
      throw new Error(err.error || 'Failed to create project');
    }
    const data = await res.json();
    return data.project;
  }

  static async getProjects(params?: { search?: string; sort?: string; status?: string }): Promise<Project[]> {
    const query = new URLSearchParams();
    if (params?.search) query.append('search', params.search);
    if (params?.sort) query.append('sort', params.sort);
    if (params?.status) query.append('status', params.status);

    const res = await fetch(`/api/projects?${query.toString()}`);
    if (!res.ok) throw new Error('Failed to list projects');
    const data = await res.json();
    return data.projects || [];
  }

  static async getProject(id: string): Promise<Project> {
    const res = await fetch(`/api/projects/${id}`);
    if (!res.ok) throw new Error('Failed to get project');
    const data = await res.json();
    return data.project;
  }

  static async deleteProject(id: string): Promise<void> {
    const res = await fetch(`/api/projects/${id}`, { method: 'DELETE' });
    if (!res.ok) throw new Error('Failed to delete project');
  }

  static async startGeneration(id: string): Promise<Project> {
    const res = await fetch(`/api/projects/${id}/start`, { method: 'POST' });
    if (!res.ok) throw new Error('Failed to start generation');
    const data = await res.json();
    return data.project;
  }

  static async cancelGeneration(id: string): Promise<Project> {
    const res = await fetch(`/api/projects/${id}/cancel`, { method: 'POST' });
    if (!res.ok) throw new Error('Failed to cancel generation');
    const data = await res.json();
    return data.project;
  }

  static async retryFailedClips(id: string): Promise<Project> {
    const res = await fetch(`/api/projects/${id}/retry-failed`, { method: 'POST' });
    if (!res.ok) throw new Error('Failed to retry failed clips');
    const data = await res.json();
    return data.project;
  }

  static async assembleProject(id: string): Promise<Project> {
    const res = await fetch(`/api/projects/${id}/assemble`, { method: 'POST' });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Assembly failed' }));
      throw new Error(err.error || 'Assembly failed');
    }
    const data = await res.json();
    return data.project;
  }
}
