import React, { useState, useEffect } from 'react';
import {
  Film,
  Play,
  RotateCw,
  StopCircle,
  Download,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Layers,
  ChevronDown,
  ChevronRight,
  Sparkles,
  ArrowLeft,
  Trash2,
  ExternalLink,
} from 'lucide-react';
import { Project, Scene } from '../types';
import { ApiService } from '../services/api';
import { DeleteConfirmModal } from '../components/DeleteConfirmModal';
import { VideoPlayerModal } from '../components/VideoPlayerModal';

interface ProjectDetailPageProps {
  projectId: string;
  onNavigate: (tab: string, projectId?: string) => void;
  onPreviewVideo: (url: string, title: string) => void;
}

export const ProjectDetailPage: React.FC<ProjectDetailPageProps> = ({
  projectId,
  onNavigate,
  onPreviewVideo,
}) => {
  const [project, setProject] = useState<Project | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [isCancelling, setIsCancelling] = useState(false);
  const [isRetrying, setIsRetrying] = useState(false);
  const [isStarting, setIsStarting] = useState(false);
  const [isAssembling, setIsAssembling] = useState(false);

  const [expandedChapters, setExpandedChapters] = useState<Record<string, boolean>>({});
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  // Poll project details
  useEffect(() => {
    let isMounted = true;
    let pollTimeout: any = null;

    const fetchProject = async () => {
      try {
        const data = await ApiService.getProject(projectId);
        if (isMounted) {
          setProject(data);
          setError(null);
          setIsLoading(false);

          // Auto-expand the first chapter or chapter currently generating
          setExpandedChapters((prev) => {
            if (Object.keys(prev).length === 0 && data.chapters.length > 0) {
              const activeChap = data.chapters.find((c) =>
                c.scenes.some((s) => s.status === 'GENERATING' || s.status === 'PENDING')
              );
              const targetId = activeChap ? activeChap.chapterId : data.chapters[0].chapterId;
              return { [targetId]: true };
            }
            return prev;
          });

          // Continue polling if generating, queued, or assembling
          if (
            data.status === 'GENERATING' ||
            data.status === 'QUEUED' ||
            data.status === 'ASSEMBLING' ||
            data.status === 'PLANNING'
          ) {
            pollTimeout = setTimeout(fetchProject, 3000);
          }
        }
      } catch (err: any) {
        if (isMounted) {
          setError(err.message || 'Failed to load project details.');
          setIsLoading(false);
        }
      }
    };

    fetchProject();

    return () => {
      isMounted = false;
      if (pollTimeout) clearTimeout(pollTimeout);
    };
  }, [projectId]);

  const toggleChapter = (chapterId: string) => {
    setExpandedChapters((prev) => ({
      ...prev,
      [chapterId]: !prev[chapterId],
    }));
  };

  const handleStartGeneration = async () => {
    setIsStarting(true);
    try {
      const updated = await ApiService.startGeneration(projectId);
      setProject(updated);
    } catch (err: any) {
      setError(err?.message || 'Failed to start generation.');
    } finally {
      setIsStarting(false);
    }
  };

  const handleCancelGeneration = async () => {
    setIsCancelling(true);
    try {
      const updated = await ApiService.cancelGeneration(projectId);
      setProject(updated);
    } catch (err: any) {
      setError(err?.message || 'Failed to cancel generation.');
    } finally {
      setIsCancelling(false);
    }
  };

  const handleRetryFailed = async () => {
    setIsRetrying(true);
    try {
      const updated = await ApiService.retryFailedClips(projectId);
      setProject(updated);
    } catch (err: any) {
      setError(err?.message || 'Failed to retry clips.');
    } finally {
      setIsRetrying(false);
    }
  };

  const handleAssemble = async () => {
    setIsAssembling(true);
    try {
      const updated = await ApiService.assembleProject(projectId);
      setProject(updated);
    } catch (err: any) {
      setError(err?.message || 'Failed to assemble video.');
    } finally {
      setIsAssembling(false);
    }
  };

  const handleDelete = async () => {
    setIsDeleting(true);
    try {
      await ApiService.deleteProject(projectId);
      setShowDeleteModal(false);
      onNavigate('projects');
    } catch (err: any) {
      setError(err?.message || 'Failed to delete project.');
    } finally {
      setIsDeleting(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[50vh] space-y-4">
        <div className="w-8 h-8 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin" />
        <p className="text-xs text-neutral-400 font-mono">Loading project data...</p>
      </div>
    );
  }

  if (!project) {
    return (
      <div className="p-8 text-center space-y-4">
        <p className="text-sm text-neutral-400">Project not found or was deleted.</p>
        <button
          onClick={() => onNavigate('projects')}
          className="px-4 py-2 text-xs font-semibold text-neutral-950 bg-cyan-400 rounded-lg"
        >
          Return to Projects
        </button>
      </div>
    );
  }

  const durationMin = Math.round(project.requestedDuration / 60);
  const remainingClips = Math.max(0, project.totalClips - project.completedClips);

  // Find currently active chapter index
  let activeChapterIndex = 1;
  const currentChapter = project.chapters.find((c) =>
    c.scenes.some((s) => s.status === 'GENERATING' || s.status === 'PENDING')
  );
  if (currentChapter) {
    activeChapterIndex = currentChapter.chapterIndex;
  }

  const downloadFilename = project.finalVideoUrl ? project.finalVideoUrl.split('/').pop() : `${project.id}.mp4`;
  const downloadUrl = `/api/storage/download/${downloadFilename}`;

  return (
    <div className="max-w-5xl mx-auto space-y-8 animate-fade-in pb-20">
      {/* Top Breadcrumb & Action bar */}
      <div className="flex items-center justify-between pb-4 border-b border-neutral-800">
        <button
          onClick={() => onNavigate('projects')}
          className="flex items-center gap-1.5 text-xs font-medium text-neutral-400 hover:text-white transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back to Projects</span>
        </button>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowDeleteModal(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-neutral-400 hover:text-rose-400 hover:bg-neutral-900 rounded-lg transition-colors cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Delete</span>
          </button>
        </div>
      </div>

      {/* Error message */}
      {error && (
        <div className="p-4 rounded-xl border border-rose-500/30 bg-rose-500/10 text-rose-300 text-xs flex items-center justify-between">
          <span>{error}</span>
          <button onClick={() => setError(null)} className="text-rose-400 hover:underline">
            Dismiss
          </button>
        </div>
      )}

      {/* Hero Project Header */}
      <div className="space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h1 className="text-xl sm:text-2xl font-extrabold text-white">{project.title}</h1>
          <span
            className={`text-xs font-semibold px-2.5 py-1 rounded-md border ${
              project.status === 'COMPLETED'
                ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-400'
                : project.status === 'GENERATING' || project.status === 'ASSEMBLING'
                ? 'border-cyan-500/30 bg-cyan-500/10 text-cyan-400 animate-pulse'
                : project.status === 'FAILED'
                ? 'border-rose-500/30 bg-rose-500/10 text-rose-400'
                : 'border-neutral-700 bg-neutral-800 text-neutral-400'
            }`}
          >
            {project.status}
          </span>
        </div>
        <p className="text-xs sm:text-sm text-neutral-400 leading-relaxed max-w-3xl">{project.prompt}</p>

        <div className="flex flex-wrap items-center gap-4 text-xs text-neutral-400 pt-1">
          <span className="font-mono tabular-nums">
            Duration: {project.requestedDuration >= 60 ? `${durationMin} min` : `${project.requestedDuration}s`}
          </span>
          <span>·</span>
          <span className="font-mono tabular-nums">Clips: {project.totalClips}</span>
          <span>·</span>
          <span>Format: {project.resolution} ({project.aspectRatio})</span>
          <span>·</span>
          <span>Model: {project.model}</span>
        </div>
      </div>

      {/* Completed Video Player Card */}
      {project.status === 'COMPLETED' && project.finalVideoUrl && (
        <div className="rounded-3xl border border-emerald-500/30 bg-gradient-to-b from-neutral-900 to-neutral-950 p-6 space-y-5 shadow-2xl">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                <CheckCircle2 className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base font-bold text-white">Your video is ready.</h2>
                <p className="text-xs text-neutral-400">All scenes rendered and assembled with FFmpeg</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <a
                href={downloadUrl}
                download
                className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-neutral-950 bg-cyan-400 hover:bg-cyan-300 rounded-xl transition-all shadow-sm"
              >
                <Download className="w-3.5 h-3.5 stroke-[2.5]" />
                <span>Download Video</span>
              </a>
              <button
                onClick={() => onNavigate('create')}
                className="px-3.5 py-2 text-xs font-medium text-neutral-300 hover:text-white bg-neutral-800 hover:bg-neutral-700 rounded-xl transition-colors cursor-pointer"
              >
                Create Another Video
              </button>
            </div>
          </div>

          <div className="relative aspect-video w-full rounded-2xl overflow-hidden bg-black border border-neutral-800">
            <video
              src={project.finalVideoUrl}
              controls
              playsInline
              className="w-full h-full object-contain"
            />
          </div>
        </div>
      )}

      {/* Live Generation Progress UI */}
      {(project.status === 'GENERATING' ||
        project.status === 'ASSEMBLING' ||
        project.status === 'QUEUED' ||
        project.status === 'PLANNING' ||
        project.status === 'FAILED' ||
        project.status === 'CANCELLED' ||
        project.status === 'DRAFT') && (
        <div className="rounded-2xl border border-neutral-800 bg-neutral-900/60 p-6 space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="space-y-1">
              <span className="text-xs font-semibold text-cyan-400 uppercase tracking-wider">
                {project.status === 'GENERATING'
                  ? 'Generating your video'
                  : project.status === 'ASSEMBLING'
                  ? 'Assembling final video'
                  : project.status === 'QUEUED'
                  ? 'Queued for generation'
                  : project.status === 'CANCELLED'
                  ? 'Generation Paused'
                  : 'Ready to Render'}
              </span>
              <p className="text-sm font-medium text-white">
                Chapter {activeChapterIndex} of {project.chapters.length} · Clip {project.completedClips + 1} of{' '}
                {project.totalClips}
              </p>
            </div>

            {/* Action buttons */}
            <div className="flex items-center gap-2.5">
              {project.status === 'GENERATING' && (
                <button
                  onClick={handleCancelGeneration}
                  disabled={isCancelling}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-amber-300 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 rounded-lg transition-colors cursor-pointer"
                >
                  <StopCircle className="w-3.5 h-3.5" />
                  <span>{isCancelling ? 'Cancelling...' : 'Cancel Generation'}</span>
                </button>
              )}

              {(project.status === 'CANCELLED' || project.status === 'DRAFT') && (
                <button
                  onClick={handleStartGeneration}
                  disabled={isStarting}
                  className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-neutral-950 bg-cyan-400 hover:bg-cyan-300 rounded-lg transition-colors cursor-pointer"
                >
                  <Play className="w-3.5 h-3.5" />
                  <span>{isStarting ? 'Starting...' : 'Resume Project'}</span>
                </button>
              )}

              {project.failedClips > 0 && (
                <button
                  onClick={handleRetryFailed}
                  disabled={isRetrying}
                  className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-500 rounded-lg transition-colors cursor-pointer"
                >
                  <RotateCw className={`w-3.5 h-3.5 ${isRetrying ? 'animate-spin' : ''}`} />
                  <span>Retry Failed Clips ({project.failedClips})</span>
                </button>
              )}

              {project.completedClips === project.totalClips && (
                <button
                  onClick={handleAssemble}
                  disabled={isAssembling}
                  className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-neutral-950 bg-cyan-400 hover:bg-cyan-300 rounded-lg transition-colors cursor-pointer"
                >
                  <Film className="w-3.5 h-3.5" />
                  <span>{isAssembling ? 'Assembling...' : 'Assemble Video'}</span>
                </button>
              )}
            </div>
          </div>

          {/* Large Progress Bar & Percentage */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-mono text-cyan-400 text-base font-bold tabular-nums">
                {project.progress.toFixed(1)}%
              </span>
              <span className="text-neutral-400 font-mono tabular-nums">
                {project.completedClips} / {project.totalClips} clips completed
              </span>
            </div>
            <div className="w-full h-3 rounded-full bg-neutral-950 overflow-hidden border border-neutral-800">
              <div
                className={`h-full transition-all duration-500 ${
                  project.status === 'FAILED'
                    ? 'bg-rose-500'
                    : 'bg-cyan-400'
                }`}
                style={{ width: `${project.progress}%` }}
              />
            </div>
          </div>

          {/* Generation Stats Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div className="p-3 rounded-xl border border-neutral-800 bg-neutral-950/60">
              <span className="text-neutral-500">Completed Clips</span>
              <p className="font-bold text-emerald-400 font-mono text-sm tabular-nums mt-0.5">
                {project.completedClips}
              </p>
            </div>

            <div className="p-3 rounded-xl border border-neutral-800 bg-neutral-950/60">
              <span className="text-neutral-500">Failed Clips</span>
              <p className="font-bold text-rose-400 font-mono text-sm tabular-nums mt-0.5">
                {project.failedClips}
              </p>
            </div>

            <div className="p-3 rounded-xl border border-neutral-800 bg-neutral-950/60">
              <span className="text-neutral-500">Remaining Workload</span>
              <p className="font-bold text-cyan-400 font-mono text-sm tabular-nums mt-0.5">
                {remainingClips} clips
              </p>
            </div>

            <div className="p-3 rounded-xl border border-neutral-800 bg-neutral-950/60">
              <span className="text-neutral-500">Active Stage</span>
              <p className="font-bold text-white font-mono text-sm truncate mt-0.5">
                {project.status === 'ASSEMBLING' ? 'FFmpeg Concat' : 'Veo Render'}
              </p>
            </div>
          </div>

          {/* Current Status Callout */}
          <div className="p-3.5 rounded-xl border border-neutral-800 bg-neutral-950 text-xs text-neutral-400 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-cyan-400 shrink-0" />
              <span>{project.currentStatusMessage || 'Pipeline running...'}</span>
            </div>
            <span className="text-[11px] text-neutral-500 hidden sm:inline">
              Generation time varies depending on model availability.
            </span>
          </div>
        </div>
      )}

      {/* Chapters & Scenes Timeline Accordion */}
      <div className="space-y-4">
        <div>
          <h3 className="text-base font-bold text-white">Video Blueprint & Scene Timeline</h3>
          <p className="text-xs text-neutral-400">
            Structured narrative breakdown into individual Veo clips with continuity instructions
          </p>
        </div>

        <div className="space-y-3">
          {project.chapters.map((chapter) => {
            const isExpanded = Boolean(expandedChapters[chapter.chapterId]);
            const completedInChap = chapter.scenes.filter((s) => s.status === 'COMPLETED').length;

            return (
              <div
                key={chapter.chapterId}
                className="rounded-2xl border border-neutral-800 bg-neutral-900/40 overflow-hidden transition-all"
              >
                {/* Chapter Accordion Header */}
                <button
                  type="button"
                  onClick={() => toggleChapter(chapter.chapterId)}
                  className="w-full p-4 flex items-center justify-between text-left hover:bg-neutral-850 transition-colors cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    {isExpanded ? (
                      <ChevronDown className="w-4 h-4 text-cyan-400" />
                    ) : (
                      <ChevronRight className="w-4 h-4 text-neutral-400" />
                    )}
                    <div>
                      <h4 className="text-sm font-bold text-white">{chapter.title}</h4>
                      <p className="text-xs text-neutral-400 line-clamp-1">{chapter.description}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 text-xs">
                    <span className="font-mono text-neutral-400 tabular-nums">
                      {completedInChap} / {chapter.scenes.length} clips
                    </span>
                    <span className="font-mono text-neutral-500">
                      ~{Math.round(chapter.estimatedDuration)}s
                    </span>
                  </div>
                </button>

                {/* Scenes Grid */}
                {isExpanded && (
                  <div className="p-4 pt-1 border-t border-neutral-800/80 space-y-3 bg-neutral-950/40">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {chapter.scenes.map((scene) => (
                        <div
                          key={scene.sceneId}
                          className="rounded-xl border border-neutral-800 bg-neutral-900/60 p-3.5 space-y-2.5 flex flex-col justify-between"
                        >
                          <div className="space-y-1.5">
                            <div className="flex items-center justify-between text-xs">
                              <span className="font-semibold text-white font-mono">
                                Shot #{scene.sceneIndex} ({scene.duration}s)
                              </span>
                              <span
                                className={`text-[10px] font-semibold px-2 py-0.5 rounded border ${
                                  scene.status === 'COMPLETED'
                                    ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-400'
                                    : scene.status === 'GENERATING'
                                    ? 'border-cyan-500/30 bg-cyan-500/10 text-cyan-400 animate-pulse'
                                    : scene.status === 'FAILED'
                                    ? 'border-rose-500/30 bg-rose-500/10 text-rose-400'
                                    : 'border-neutral-800 bg-neutral-950 text-neutral-500'
                                }`}
                              >
                                {scene.status}
                              </span>
                            </div>

                            <p className="text-xs text-neutral-300 leading-relaxed">{scene.prompt}</p>

                            {scene.cameraMovement && (
                              <p className="text-[11px] text-neutral-400 font-mono">
                                Camera: {scene.cameraMovement}
                              </p>
                            )}

                            {scene.error && (
                              <p className="text-[11px] text-rose-400 bg-rose-500/10 p-2 rounded-lg border border-rose-500/20">
                                {scene.error}
                              </p>
                            )}
                          </div>

                          {/* Clip Preview if completed */}
                          <div className="pt-2 border-t border-neutral-800/80 flex items-center justify-between text-xs">
                            <span className="text-[11px] text-neutral-500 truncate max-w-[180px]">
                              {scene.visualContinuity || 'Consistent 8K aesthetic'}
                            </span>
                            {scene.clipUrl && (
                              <button
                                onClick={() => onPreviewVideo(scene.clipUrl!, scene.title)}
                                className="flex items-center gap-1 text-cyan-400 hover:text-cyan-300 font-medium cursor-pointer"
                              >
                                <Play className="w-3 h-3" />
                                <span>Preview Clip</span>
                              </button>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      <DeleteConfirmModal
        isOpen={showDeleteModal}
        title={project.title}
        onClose={() => setShowDeleteModal(false)}
        onConfirm={handleDelete}
        isDeleting={isDeleting}
      />
    </div>
  );
};
