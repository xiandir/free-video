import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Video,
  Clock,
  Layers,
  Volume2,
  Film,
  AlertCircle,
  HelpCircle,
  Check,
  Zap,
} from 'lucide-react';
import { ModelCapabilityService, MAX_PROJECT_DURATION_SECONDS } from '../config/modelCapabilities';
import { AspectRatio, Project, Resolution, SystemStatus } from '../types';
import { ApiService } from '../services/api';
import { WorkloadModal } from '../components/WorkloadModal';

interface CreateVideoPageProps {
  systemStatus: SystemStatus | null;
  initialPrompt?: string;
  initialDuration?: number;
  initialStyle?: string;
  initialModel?: string;
  initialAspectRatio?: AspectRatio;
  initialResolution?: Resolution;
  onProjectCreated: (project: Project) => void;
}

const DURATION_PRESETS = [
  { label: '10s', seconds: 10 },
  { label: '30s', seconds: 30 },
  { label: '1 min', seconds: 60 },
  { label: '5 min', seconds: 300 },
  { label: '10 min', seconds: 600 },
  { label: '20 min', seconds: 1200 },
  { label: '30 min', seconds: 1800 },
  { label: '60 min', seconds: 3600 },
  { label: '90 min', seconds: 5400 },
  { label: '120 min', seconds: 7200 },
];

const STYLES = [
  'Cinematic',
  'Cinematic Documentary',
  'Photorealistic 8K',
  'Automotive Commercial',
  'Sci-Fi Epic',
  'Aerial Drone',
  'Vintage 35mm Film',
  'Hyper-lapse',
  'High Fantasy',
  'Fashion Editorial',
];

export const CreateVideoPage: React.FC<CreateVideoPageProps> = ({
  systemStatus,
  initialPrompt = '',
  initialDuration = 60,
  initialStyle = 'Cinematic',
  initialModel = 'veo-3.1-generate-preview',
  initialAspectRatio = '16:9',
  initialResolution = '720p',
  onProjectCreated,
}) => {
  const [prompt, setPrompt] = useState(initialPrompt);
  const [enhancedPrompt, setEnhancedPrompt] = useState('');
  const [isEnhancing, setIsEnhancing] = useState(false);
  const [enhanceSuccess, setEnhanceSuccess] = useState(false);

  const [durationSeconds, setDurationSeconds] = useState(initialDuration);
  const [customDurationInput, setCustomDurationInput] = useState('');
  const [isCustomDuration, setIsCustomDuration] = useState(false);

  const [selectedModel, setSelectedModel] = useState(initialModel);
  const [selectedStyle, setSelectedStyle] = useState(initialStyle);
  const [selectedAspectRatio, setSelectedAspectRatio] = useState<AspectRatio>(initialAspectRatio);
  const [selectedResolution, setSelectedResolution] = useState<Resolution>(initialResolution);
  const [selectedClipDuration, setSelectedClipDuration] = useState(8);

  const [audioEnabled, setAudioEnabled] = useState(true);
  const [audioInstructions, setAudioInstructions] = useState('');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showWorkloadModal, setShowWorkloadModal] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Quick Prompt inspiration
  const samplePrompts = [
    {
      label: 'Kampala Sports Car',
      prompt:
        'Create a cinematic video of a futuristic black sports car driving through Kampala at night. The road is wet from rain, neon lights reflect on the vehicle, pedestrians walk along the streets, and the camera follows the car with smooth cinematic tracking shots.',
    },
    {
      label: 'African Wildlife (2h)',
      prompt:
        'Create a 2-hour documentary about African wildlife on the Serengeti savannah. Capture elephant herds, lions basking in golden sunrise mist, and wide aerial landscapes with cinematic natural ambience.',
      duration: 7200,
    },
    {
      label: 'Deep Space Nebula',
      prompt:
        'An interstellar exploration ship navigates through an iridescent violet and gold nebula in deep space with panoramic planetary rings and anamorphic lens flares.',
    },
    {
      label: 'Emerald Coastal Drone',
      prompt:
        'Sweeping drone aerial footage gliding along dramatic emerald green sea cliffs with turquoise waves crashing onto white sand at golden hour.',
    },
  ];

  // Dynamic model capabilities
  const availableModels = ModelCapabilityService.getAvailableModels();
  const currentModelCaps = ModelCapabilityService.getModelCapabilities(selectedModel);
  const supportedDurations = currentModelCaps.supportedDurations;
  const supportedAspectRatios = currentModelCaps.supportedAspectRatios;
  const supportedResolutions = currentModelCaps.supportedResolutions;

  // Clip calculation
  const { totalClips, clipDuration, isOverLimit } = ModelCapabilityService.calculateClips(
    selectedModel,
    durationSeconds,
    selectedClipDuration
  );

  // Sync aspect ratio and resolution if model changes
  useEffect(() => {
    if (!supportedAspectRatios.includes(selectedAspectRatio)) {
      setSelectedAspectRatio(supportedAspectRatios[0] || '16:9');
    }
    if (!supportedResolutions.includes(selectedResolution)) {
      setSelectedResolution(supportedResolutions[0] || '720p');
    }
  }, [selectedModel]);

  const handlePresetDuration = (seconds: number) => {
    setIsCustomDuration(false);
    setDurationSeconds(seconds);
    setCustomDurationInput('');
    setErrorMessage(null);
  };

  const handleCustomDurationChange = (val: string) => {
    setCustomDurationInput(val);
    const num = parseInt(val, 10);
    if (!isNaN(num)) {
      // Input in minutes
      const seconds = num * 60;
      setDurationSeconds(seconds);
      if (seconds > MAX_PROJECT_DURATION_SECONDS) {
        setErrorMessage('FREEVIDAi currently supports projects up to 120 minutes.');
      } else {
        setErrorMessage(null);
      }
    }
  };

  const handleEnhancePrompt = async () => {
    if (!prompt.trim()) {
      setErrorMessage('Please enter a prompt description to enhance.');
      return;
    }

    setIsEnhancing(true);
    setErrorMessage(null);

    try {
      const result = await ApiService.enhancePrompt(prompt, selectedStyle);
      setEnhancedPrompt(result);
      setEnhanceSuccess(true);
      setTimeout(() => setEnhanceSuccess(false), 3000);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to enhance prompt.');
    } finally {
      setIsEnhancing(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!prompt.trim()) {
      setErrorMessage('Please describe the video you want to create.');
      return;
    }

    if (durationSeconds > MAX_PROJECT_DURATION_SECONDS) {
      setErrorMessage('FREEVIDAi currently supports projects up to 120 minutes.');
      return;
    }

    // Open Workload confirmation modal
    setShowWorkloadModal(true);
  };

  const handleConfirmAndStart = async () => {
    setIsSubmitting(true);
    setErrorMessage(null);

    try {
      const project = await ApiService.createProject({
        prompt: prompt.trim(),
        enhancedPrompt: enhancedPrompt.trim() || undefined,
        durationSeconds,
        modelId: selectedModel,
        style: selectedStyle,
        aspectRatio: selectedAspectRatio,
        resolution: selectedResolution,
        audioEnabled,
        audioInstructions: audioInstructions.trim() || undefined,
      });

      // Automatically queue the generation job
      const startedProject = await ApiService.startGeneration(project.id);
      setShowWorkloadModal(false);
      onProjectCreated(startedProject);
    } catch (err: any) {
      setShowWorkloadModal(false);
      setErrorMessage(err?.message || 'Failed to initialize project generation.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-fade-in pb-16">
      {/* Page Header */}
      <div className="space-y-1">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white">What do you want to create?</h1>
        <p className="text-sm text-neutral-400">
          Describe your vision. FREEVIDAi plans scenes, ensures visual continuity, and orchestrates Veo video clips.
        </p>
      </div>

      {/* Error Banner */}
      {errorMessage && (
        <div className="p-4 rounded-xl border border-rose-500/30 bg-rose-500/10 text-rose-300 text-sm flex items-start gap-3">
          <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <p className="font-semibold">Notice</p>
            <p className="text-xs text-rose-300/90">{errorMessage}</p>
          </div>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* 1. Large Prompt Editor */}
        <div className="rounded-2xl border border-neutral-800 bg-neutral-900/60 p-5 space-y-4 shadow-xl">
          <div className="flex items-center justify-between">
            <label className="text-xs font-semibold text-neutral-300 uppercase tracking-wider">
              Video Description & Narrative
            </label>
            <button
              type="button"
              onClick={handleEnhancePrompt}
              disabled={isEnhancing || !prompt.trim()}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-neutral-950 bg-cyan-400 hover:bg-cyan-300 disabled:opacity-50 disabled:pointer-events-none rounded-lg transition-all cursor-pointer"
            >
              {isEnhancing ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-neutral-950 border-t-transparent rounded-full animate-spin" />
                  <span>Enhancing with Gemini...</span>
                </>
              ) : enhanceSuccess ? (
                <>
                  <Check className="w-3.5 h-3.5" />
                  <span>Prompt Enhanced!</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-3.5 h-3.5 text-neutral-950" />
                  <span>Enhance Prompt</span>
                </>
              )}
            </button>
          </div>

          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            rows={4}
            placeholder="Describe the video you want to create... e.g. Create a cinematic video of a futuristic sports car driving through Kampala at night, with neon reflections, dramatic camera movements and realistic city traffic."
            className="w-full rounded-xl border border-neutral-800 bg-neutral-950 px-4 py-3 text-sm text-white placeholder-neutral-500 focus:border-cyan-500 focus:outline-none focus:ring-1 focus:ring-cyan-500/50 transition-colors resize-y leading-relaxed"
          />

          {/* Quick inspiration pills */}
          <div className="space-y-1.5">
            <span className="text-[11px] text-neutral-500 font-medium">Quick examples:</span>
            <div className="flex flex-wrap gap-2">
              {samplePrompts.map((s, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => {
                    setPrompt(s.prompt);
                    if (s.duration) {
                      setDurationSeconds(s.duration);
                      setIsCustomDuration(false);
                    }
                  }}
                  className="px-2.5 py-1 text-xs rounded-md bg-neutral-800/80 hover:bg-neutral-800 text-neutral-300 hover:text-white border border-neutral-700/50 transition-colors cursor-pointer"
                >
                  {s.label}
                </button>
              ))}
            </div>
          </div>

          {/* Display Enhanced Prompt Accordion if generated */}
          {enhancedPrompt && (
            <div className="p-4 rounded-xl border border-cyan-500/30 bg-cyan-500/5 space-y-2 text-xs">
              <div className="flex items-center justify-between text-cyan-400 font-semibold">
                <span className="flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" />
                  Director's Enhanced Prompt (Gemini AI)
                </span>
                <button
                  type="button"
                  onClick={() => setPrompt(enhancedPrompt)}
                  className="text-cyan-400 hover:underline cursor-pointer"
                >
                  Apply to Main Input
                </button>
              </div>
              <p className="text-neutral-300 leading-relaxed">{enhancedPrompt}</p>
            </div>
          )}
        </div>

        {/* 2. Duration Selector with Presets & Custom Duration */}
        <div className="rounded-2xl border border-neutral-800 bg-neutral-900/60 p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-cyan-400" />
              <label className="text-xs font-semibold text-neutral-300 uppercase tracking-wider">
                Video Duration
              </label>
            </div>
            <span className="text-xs text-neutral-400 font-mono tabular-nums">
              Selected: {durationSeconds >= 60 ? `${Math.round(durationSeconds / 60)} min` : `${durationSeconds}s`}
            </span>
          </div>

          {/* Preset Buttons */}
          <div className="grid grid-cols-5 sm:grid-cols-10 gap-2">
            {DURATION_PRESETS.map((p) => {
              const isSelected = !isCustomDuration && durationSeconds === p.seconds;
              return (
                <button
                  key={p.seconds}
                  type="button"
                  onClick={() => handlePresetDuration(p.seconds)}
                  className={`py-2 px-1 text-center text-xs font-mono font-medium rounded-lg border transition-all cursor-pointer ${
                    isSelected
                      ? 'border-cyan-400 bg-cyan-400/10 text-cyan-300 font-bold shadow-sm'
                      : 'border-neutral-800 bg-neutral-950/60 text-neutral-400 hover:border-neutral-700 hover:text-white'
                  }`}
                >
                  {p.label}
                </button>
              );
            })}
          </div>

          {/* Custom Duration Toggle & Input */}
          <div className="pt-2 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs border-t border-neutral-800/80">
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => {
                  setIsCustomDuration(true);
                  if (!customDurationInput) setCustomDurationInput('15');
                  setDurationSeconds(15 * 60);
                }}
                className={`px-3 py-1.5 rounded-lg border font-medium transition-colors cursor-pointer ${
                  isCustomDuration
                    ? 'border-cyan-400 bg-cyan-400/10 text-cyan-300'
                    : 'border-neutral-800 bg-neutral-950/60 text-neutral-400 hover:text-white'
                }`}
              >
                Custom Duration (up to 120 min)
              </button>

              {isCustomDuration && (
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    min="1"
                    max="120"
                    value={customDurationInput}
                    onChange={(e) => handleCustomDurationChange(e.target.value)}
                    className="w-20 px-2.5 py-1.5 rounded-lg border border-neutral-800 bg-neutral-950 text-white font-mono text-xs focus:border-cyan-500 focus:outline-none"
                    placeholder="Minutes"
                  />
                  <span className="text-neutral-400">minutes</span>
                </div>
              )}
            </div>

            <span className="text-[11px] text-neutral-500">Maximum project duration: 120 minutes (2 hours)</span>
          </div>
        </div>

        {/* 3. Model Capability & Settings Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Active Model Selector */}
          <div className="rounded-2xl border border-neutral-800 bg-neutral-900/60 p-5 space-y-3">
            <label className="text-xs font-semibold text-neutral-300 uppercase tracking-wider">
              AI Video Model
            </label>
            <div className="space-y-2">
              {availableModels.map((m) => (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => setSelectedModel(m.id)}
                  className={`w-full p-3 rounded-xl border text-left transition-all cursor-pointer flex items-start justify-between gap-3 ${
                    selectedModel === m.id
                      ? 'border-cyan-500/50 bg-cyan-500/10 text-white'
                      : 'border-neutral-800 bg-neutral-950/60 text-neutral-400 hover:border-neutral-700 hover:text-white'
                  }`}
                >
                  <div className="space-y-1 min-w-0">
                    <p className="text-xs font-bold text-white truncate">{m.name}</p>
                    <p className="text-[11px] text-neutral-400 leading-snug line-clamp-2">{m.description}</p>
                  </div>
                  {selectedModel === m.id && <Check className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />}
                </button>
              ))}
            </div>
          </div>

          {/* Visual Style & Clip Duration */}
          <div className="rounded-2xl border border-neutral-800 bg-neutral-900/60 p-5 space-y-4">
            <div className="space-y-2">
              <label className="text-xs font-semibold text-neutral-300 uppercase tracking-wider">
                Visual Style
              </label>
              <select
                value={selectedStyle}
                onChange={(e) => setSelectedStyle(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-neutral-800 bg-neutral-950 text-xs text-white focus:border-cyan-500 focus:outline-none"
              >
                {STYLES.map((st) => (
                  <option key={st} value={st}>
                    {st}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-semibold text-neutral-300 uppercase tracking-wider">
                Model Clip Duration
              </label>
              <div className="flex gap-2">
                {supportedDurations.map((dur) => (
                  <button
                    key={dur}
                    type="button"
                    onClick={() => setSelectedClipDuration(dur)}
                    className={`flex-1 py-1.5 text-xs font-mono font-medium rounded-lg border transition-colors cursor-pointer ${
                      selectedClipDuration === dur
                        ? 'border-cyan-400 bg-cyan-400/10 text-cyan-300 font-bold'
                        : 'border-neutral-800 bg-neutral-950 text-neutral-400 hover:border-neutral-700 hover:text-white'
                    }`}
                  >
                    {dur}s clips
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* 4. Aspect Ratio, Resolution & Audio */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {/* Aspect Ratio */}
          <div className="rounded-2xl border border-neutral-800 bg-neutral-900/60 p-4 space-y-2">
            <label className="text-xs font-semibold text-neutral-300 uppercase tracking-wider">
              Aspect Ratio
            </label>
            <div className="flex gap-2">
              {supportedAspectRatios.map((ar) => (
                <button
                  key={ar}
                  type="button"
                  onClick={() => setSelectedAspectRatio(ar)}
                  className={`flex-1 py-2 text-xs font-mono font-medium rounded-lg border transition-colors cursor-pointer ${
                    selectedAspectRatio === ar
                      ? 'border-cyan-400 bg-cyan-400/10 text-cyan-300 font-bold'
                      : 'border-neutral-800 bg-neutral-950 text-neutral-400 hover:border-neutral-700 hover:text-white'
                  }`}
                >
                  {ar} {ar === '16:9' ? '(Landscape)' : '(Portrait)'}
                </button>
              ))}
            </div>
          </div>

          {/* Resolution */}
          <div className="rounded-2xl border border-neutral-800 bg-neutral-900/60 p-4 space-y-2">
            <label className="text-xs font-semibold text-neutral-300 uppercase tracking-wider">
              Resolution
            </label>
            <div className="flex gap-2">
              {supportedResolutions.map((res) => (
                <button
                  key={res}
                  type="button"
                  onClick={() => setSelectedResolution(res)}
                  className={`flex-1 py-2 text-xs font-mono font-medium rounded-lg border transition-colors cursor-pointer ${
                    selectedResolution === res
                      ? 'border-cyan-400 bg-cyan-400/10 text-cyan-300 font-bold'
                      : 'border-neutral-800 bg-neutral-950 text-neutral-400 hover:border-neutral-700 hover:text-white'
                  }`}
                >
                  {res}
                </button>
              ))}
            </div>
          </div>

          {/* Native Audio Toggle */}
          <div className="rounded-2xl border border-neutral-800 bg-neutral-900/60 p-4 space-y-2 flex flex-col justify-between">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-neutral-300 uppercase tracking-wider flex items-center gap-1.5">
                <Volume2 className="w-3.5 h-3.5 text-cyan-400" />
                Native Audio
              </label>
              <input
                type="checkbox"
                checked={audioEnabled}
                onChange={(e) => setAudioEnabled(e.target.checked)}
                className="w-4 h-4 rounded text-cyan-400 focus:ring-0 bg-neutral-950 border-neutral-700 cursor-pointer"
              />
            </div>
            <p className="text-[11px] text-neutral-400 leading-snug">
              Veo 3.1 synthesizes synchronized environmental audio, acoustics, and ambient Foley.
            </p>
          </div>
        </div>

        {/* 5. Dynamic Clip Calculation & Pipeline Overview */}
        <div className="p-5 rounded-2xl border border-neutral-800 bg-neutral-950/80 space-y-3">
          <div className="flex items-center justify-between text-xs">
            <span className="font-semibold text-white flex items-center gap-2">
              <Layers className="w-4 h-4 text-cyan-400" />
              Dynamic Clip Calculation
            </span>
            <span className="text-neutral-400 font-mono">Model: {currentModelCaps.name}</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
            <div className="p-3 rounded-lg border border-neutral-800 bg-neutral-900/40">
              <span className="text-neutral-500">Requested Duration:</span>
              <p className="font-bold text-white font-mono tabular-nums">
                {durationSeconds >= 60 ? `${Math.round(durationSeconds / 60)} minutes` : `${durationSeconds}s`}
              </p>
            </div>

            <div className="p-3 rounded-lg border border-neutral-800 bg-neutral-900/40">
              <span className="text-neutral-500">Generation Clips:</span>
              <p className="font-bold text-cyan-400 font-mono tabular-nums">
                {totalClips} clips ({clipDuration}s each)
              </p>
            </div>

            <div className="p-3 rounded-lg border border-neutral-800 bg-neutral-900/40 col-span-2 sm:col-span-1">
              <span className="text-neutral-500">Generation Status:</span>
              <p className="font-bold text-neutral-300 font-mono tabular-nums">0 / {totalClips} ready</p>
            </div>
          </div>
        </div>

        {/* 6. Submit Button */}
        <div className="flex items-center justify-end gap-4 pt-2">
          <button
            type="submit"
            disabled={isSubmitting || isOverLimit || !prompt.trim()}
            className="w-full sm:w-auto flex items-center justify-center gap-2 px-8 py-3.5 text-sm font-bold text-neutral-950 bg-cyan-400 hover:bg-cyan-300 disabled:opacity-50 disabled:pointer-events-none rounded-xl shadow-lg transition-all cursor-pointer whitespace-nowrap"
          >
            <Video className="w-4 h-4 stroke-[2.5]" />
            <span>Generate Video</span>
          </button>
        </div>
      </form>

      {/* Workload / Cost Confirmation Modal */}
      <WorkloadModal
        isOpen={showWorkloadModal}
        onClose={() => setShowWorkloadModal(false)}
        onConfirm={handleConfirmAndStart}
        durationSeconds={durationSeconds}
        totalClips={totalClips}
        clipDuration={clipDuration}
        modelName={currentModelCaps.name}
        resolution={selectedResolution}
        aspectRatio={selectedAspectRatio}
        isStarting={isSubmitting}
      />
    </div>
  );
};
