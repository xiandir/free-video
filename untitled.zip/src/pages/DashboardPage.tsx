import React from 'react';
import {
  Film,
  Video,
  Play,
  Clock,
  Sparkles,
  ArrowRight,
  CheckCircle2,
  Layers,
  AlertCircle,
  ExternalLink,
} from 'lucide-react';
import { Project, SystemStatus } from '../types';
import { TEMPLATES } from '../data/templates';

interface DashboardPageProps {
  projects: Project[];
  systemStatus: SystemStatus | null;
  onNavigate: (tab: string, projectId?: string) => void;
  onSelectTemplate: (templateId: string) => void;
  onPreviewVideo: (url: string, title: string) => void;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({
  projects,
  systemStatus,
  onNavigate,
  onSelectTemplate,
  onPreviewVideo,
}) => {
  // Statistics calculations
  const totalProjects = projects.length;
  const processingCount = projects.filter(
    (p) => p.status === 'GENERATING' || p.status === 'QUEUED' || p.status === 'ASSEMBLING'
  ).length;
  const completedProjects = projects.filter((p) => p.status === 'COMPLETED');
  const completedCount = completedProjects.length;

  const totalGeneratedSeconds = completedProjects.reduce((acc, curr) => acc + (curr.requestedDuration || 0), 0);
  const totalHours = Math.floor(totalGeneratedSeconds / 3600);
  const totalMinutes = Math.floor((totalGeneratedSeconds % 3600) / 60);

  const durationFormatted =
    totalHours > 0
      ? `${totalHours}h ${totalMinutes}m`
      : totalMinutes > 0
      ? `${totalMinutes} min`
      : `${totalGeneratedSeconds}s`;

  const recentProjects = projects.slice(0, 4);

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Welcome Banner */}
      <div className="relative overflow-hidden rounded-3xl border border-neutral-800 bg-gradient-to-r from-neutral-900 via-neutral-900/90 to-neutral-950 p-6 sm:p-8">
        <div className="relative z-10 max-w-2xl space-y-3">
          <div className="flex items-center gap-2 text-cyan-400 text-xs font-semibold tracking-wider uppercase">
            <Sparkles className="w-3.5 h-3.5" />
            <span>AI Long-Form Video Orchestration</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">
            Create something amazing.
          </h1>
          <p className="text-sm sm:text-base text-neutral-400 leading-relaxed">
            Turn your ideas into cinematic AI videos. Orchestrate short Google Veo clips into cohesive narratives up to
            120 minutes with automated continuity, camera planning, and native audio.
          </p>
          <div className="pt-2 flex flex-wrap items-center gap-3">
            <button
              onClick={() => onNavigate('create')}
              className="flex items-center gap-2 px-5 py-2.5 text-xs sm:text-sm font-semibold text-neutral-950 bg-cyan-400 hover:bg-cyan-300 rounded-xl shadow-lg transition-all cursor-pointer whitespace-nowrap"
            >
              <Video className="w-4 h-4 stroke-[2.5]" />
              <span>Create New Video</span>
            </button>
            <button
              onClick={() => onNavigate('templates')}
              className="flex items-center gap-2 px-4 py-2.5 text-xs sm:text-sm font-medium text-neutral-300 hover:text-white bg-neutral-800/80 hover:bg-neutral-800 border border-neutral-700/50 rounded-xl transition-all cursor-pointer whitespace-nowrap"
            >
              <span>Explore Templates</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="absolute right-0 top-0 bottom-0 w-1/3 opacity-20 pointer-events-none bg-gradient-to-l from-cyan-500/20 to-transparent blur-2xl" />
      </div>

      {/* Statistics Section */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 rounded-2xl border border-neutral-800 bg-neutral-900/50 space-y-1">
          <div className="flex items-center justify-between text-neutral-400 text-xs font-medium">
            <span>Videos Created</span>
            <Film className="w-4 h-4 text-cyan-400" />
          </div>
          <p className="text-2xl font-bold text-white font-mono tabular-nums">{totalProjects}</p>
          <p className="text-[11px] text-neutral-500">Total planned projects</p>
        </div>

        <div className="p-4 rounded-2xl border border-neutral-800 bg-neutral-900/50 space-y-1">
          <div className="flex items-center justify-between text-neutral-400 text-xs font-medium">
            <span>Videos Processing</span>
            <Layers className="w-4 h-4 text-amber-400" />
          </div>
          <p className="text-2xl font-bold text-amber-400 font-mono tabular-nums">{processingCount}</p>
          <p className="text-[11px] text-neutral-500">Active worker queue</p>
        </div>

        <div className="p-4 rounded-2xl border border-neutral-800 bg-neutral-900/50 space-y-1">
          <div className="flex items-center justify-between text-neutral-400 text-xs font-medium">
            <span>Completed Projects</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <p className="text-2xl font-bold text-emerald-400 font-mono tabular-nums">{completedCount}</p>
          <p className="text-[11px] text-neutral-500">Assembled & ready</p>
        </div>

        <div className="p-4 rounded-2xl border border-neutral-800 bg-neutral-900/50 space-y-1">
          <div className="flex items-center justify-between text-neutral-400 text-xs font-medium">
            <span>Total Generated Duration</span>
            <Clock className="w-4 h-4 text-purple-400" />
          </div>
          <p className="text-2xl font-bold text-purple-400 font-mono tabular-nums">{durationFormatted}</p>
          <p className="text-[11px] text-neutral-500">Rendered footage</p>
        </div>
      </div>

      {/* Recent Projects Section */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-white">Recent Projects</h2>
            <p className="text-xs text-neutral-400">View progress and manage ongoing video productions</p>
          </div>
          {projects.length > 0 && (
            <button
              onClick={() => onNavigate('projects')}
              className="text-xs font-medium text-cyan-400 hover:text-cyan-300 flex items-center gap-1 cursor-pointer"
            >
              <span>View all projects</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {recentProjects.length === 0 ? (
          <div className="p-8 rounded-2xl border border-neutral-800/80 bg-neutral-900/20 text-center space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-neutral-800/50 mx-auto flex items-center justify-center text-neutral-500">
              <Film className="w-6 h-6" />
            </div>
            <div className="space-y-1">
              <h3 className="text-sm font-semibold text-white">No projects yet.</h3>
              <p className="text-xs text-neutral-400">Create your first AI video to get started.</p>
            </div>
            <button
              onClick={() => onNavigate('create')}
              className="px-4 py-2 text-xs font-semibold text-neutral-950 bg-cyan-400 hover:bg-cyan-300 rounded-lg shadow-sm transition-all cursor-pointer"
            >
              Create Video
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {recentProjects.map((project) => {
              const durationMin = Math.round(project.requestedDuration / 60);
              const durationLabel =
                project.requestedDuration >= 60
                  ? `${durationMin} min (${project.requestedDuration}s)`
                  : `${project.requestedDuration}s`;

              return (
                <div
                  key={project.id}
                  className="rounded-2xl border border-neutral-800 bg-neutral-900/40 p-4 space-y-3 hover:border-neutral-700 transition-colors"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="space-y-1 min-w-0">
                      <h4 className="text-sm font-bold text-white truncate">{project.title}</h4>
                      <p className="text-xs text-neutral-400 line-clamp-1">{project.prompt}</p>
                    </div>

                    <span
                      className={`text-[11px] font-semibold px-2 py-0.5 rounded-md border shrink-0 ${
                        project.status === 'COMPLETED'
                          ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-400'
                          : project.status === 'GENERATING' || project.status === 'ASSEMBLING'
                          ? 'border-cyan-500/30 bg-cyan-500/10 text-cyan-400 animate-pulse'
                          : project.status === 'FAILED'
                          ? 'border-rose-500/30 bg-rose-500/10 text-rose-400'
                          : 'border-neutral-700 bg-neutral-800 text-neutral-400'
                      }`}
                    >
                      {project.status}
                    </span>
                  </div>

                  {/* Progress & Clip count */}
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs text-neutral-400">
                      <span className="font-mono tabular-nums">
                        {project.completedClips} / {project.totalClips} clips
                      </span>
                      <span className="font-mono tabular-nums text-neutral-300">{project.progress}%</span>
                    </div>
                    <div className="w-full h-1.5 rounded-full bg-neutral-800 overflow-hidden">
                      <div
                        className={`h-full transition-all duration-500 ${
                          project.status === 'COMPLETED'
                            ? 'bg-emerald-400'
                            : project.status === 'FAILED'
                            ? 'bg-rose-500'
                            : 'bg-cyan-400'
                        }`}
                        style={{ width: `${project.progress}%` }}
                      />
                    </div>
                  </div>

                  {/* Metadata and Open button */}
                  <div className="flex items-center justify-between pt-2 border-t border-neutral-800/80 text-xs text-neutral-400">
                    <div className="flex items-center gap-2">
                      <span className="font-mono tabular-nums">{durationLabel}</span>
                      <span>·</span>
                      <span>{project.resolution}</span>
                    </div>

                    <div className="flex items-center gap-2">
                      {project.finalVideoUrl && (
                        <button
                          onClick={() => onPreviewVideo(project.finalVideoUrl!, project.title)}
                          className="p-1.5 rounded-lg text-neutral-300 hover:text-white hover:bg-neutral-800 transition-colors"
                          title="Play Video"
                        >
                          <Play className="w-3.5 h-3.5" />
                        </button>
                      )}
                      <button
                        onClick={() => onNavigate('project-detail', project.id)}
                        className="px-3 py-1.5 text-xs font-medium text-white bg-neutral-800 hover:bg-neutral-700 rounded-lg transition-colors cursor-pointer"
                      >
                        Open
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Featured Templates */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-white">Popular Video Templates</h2>
            <p className="text-xs text-neutral-400">Start with pre-structured cinematics and documentaries</p>
          </div>
          <button
            onClick={() => onNavigate('templates')}
            className="text-xs font-medium text-cyan-400 hover:text-cyan-300 flex items-center gap-1 cursor-pointer"
          >
            <span>Browse all</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {TEMPLATES.slice(0, 3).map((template) => (
            <div
              key={template.id}
              className="group rounded-2xl border border-neutral-800 bg-neutral-900/40 overflow-hidden hover:border-neutral-700 transition-all flex flex-col justify-between"
            >
              <div className="relative aspect-video w-full overflow-hidden bg-neutral-950">
                <img
                  src={template.coverImage}
                  alt={template.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-neutral-950 via-neutral-950/20 to-transparent" />
                <div className="absolute top-2.5 left-2.5 px-2 py-0.5 rounded-md bg-neutral-950/80 backdrop-blur-md text-[10px] font-mono font-medium text-cyan-400 border border-neutral-800">
                  {template.category}
                </div>
                <div className="absolute bottom-2.5 right-2.5 px-2 py-0.5 rounded-md bg-neutral-950/80 backdrop-blur-md text-[10px] font-mono text-neutral-300 border border-neutral-800">
                  {Math.round(template.defaultDuration / 60)} min
                </div>
              </div>

              <div className="p-4 space-y-3 flex-1 flex flex-col justify-between">
                <div className="space-y-1">
                  <h4 className="text-sm font-bold text-white group-hover:text-cyan-400 transition-colors">
                    {template.title}
                  </h4>
                  <p className="text-xs text-neutral-400 line-clamp-2">{template.description}</p>
                </div>

                <button
                  onClick={() => onSelectTemplate(template.id)}
                  className="w-full flex items-center justify-center gap-1.5 py-2 text-xs font-semibold text-neutral-200 hover:text-white bg-neutral-800 hover:bg-neutral-700 rounded-lg transition-colors cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Use Template</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
