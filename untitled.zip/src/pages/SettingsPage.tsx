import React, { useState } from 'react';
import {
  Cpu,
  ShieldCheck,
  HardDrive,
  CheckCircle2,
  AlertCircle,
  FileVideo,
  Layers,
  ExternalLink,
  Sparkles,
} from 'lucide-react';
import { SystemStatus } from '../types';
import { MODEL_CAPABILITIES } from '../config/modelCapabilities';

interface SettingsPageProps {
  systemStatus: SystemStatus | null;
  onRefreshStatus: () => void;
}

export const SettingsPage: React.FC<SettingsPageProps> = ({ systemStatus, onRefreshStatus }) => {
  const models = Object.values(MODEL_CAPABILITIES);

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-fade-in pb-20">
      {/* Header */}
      <div className="space-y-1">
        <h1 className="text-2xl font-extrabold text-white">System & Model Settings</h1>
        <p className="text-xs sm:text-sm text-neutral-400">
          Inspect model capability configurations, Google GenAI setup, FFmpeg processor, and storage
        </p>
      </div>

      {/* 1. Google Gemini & Veo API Configuration Status */}
      <div className="rounded-2xl border border-neutral-800 bg-neutral-900/40 p-5 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Google GenAI Credentials</h2>
              <p className="text-xs text-neutral-400">Server-side environment configuration</p>
            </div>
          </div>

          <div
            className={`flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-md border ${
              systemStatus?.apiConfigured
                ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-400'
                : 'border-amber-500/30 bg-amber-500/10 text-amber-400'
            }`}
          >
            {systemStatus?.apiConfigured ? (
              <>
                <CheckCircle2 className="w-4 h-4" />
                <span>API Key Configured</span>
              </>
            ) : (
              <>
                <AlertCircle className="w-4 h-4" />
                <span>Setup Required in Secrets</span>
              </>
            )}
          </div>
        </div>

        <div className="p-4 rounded-xl border border-neutral-800 bg-neutral-950 text-xs text-neutral-300 space-y-2 leading-relaxed">
          <p>
            <strong className="text-white">API Security:</strong> In accordance with Google AI Studio architecture,
            API keys are strictly managed via server environment variables (<code className="text-cyan-400">GEMINI_API_KEY</code>)
            and never exposed to frontend client code.
          </p>
          <p className="text-neutral-400">
            To configure or update your Google API credentials, click the <strong className="text-neutral-200">Settings &gt; Secrets</strong> panel
            in AI Studio. The server automatically reads the key at runtime.
          </p>
        </div>
      </div>

      {/* 2. Model Capabilities Matrix */}
      <div className="rounded-2xl border border-neutral-800 bg-neutral-900/40 p-5 space-y-4">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-lg bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400">
            <Cpu className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white">Model Capability Matrix</h2>
            <p className="text-xs text-neutral-400">Centralized specifications for currently active Google video models</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {models.map((model) => (
            <div
              key={model.id}
              className="p-4 rounded-xl border border-neutral-800 bg-neutral-950/60 space-y-3 flex flex-col justify-between"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-white">{model.name}</h3>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-neutral-800 text-neutral-400">
                    {model.id}
                  </span>
                </div>
                <p className="text-xs text-neutral-400 leading-relaxed">{model.description}</p>
              </div>

              <div className="space-y-1.5 pt-3 border-t border-neutral-800/80 text-xs text-neutral-400 font-mono">
                <div className="flex justify-between">
                  <span className="text-neutral-500">Supported Durations:</span>
                  <span className="text-white">{model.supportedDurations.map((d) => `${d}s`).join(', ')}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500">Aspect Ratios:</span>
                  <span className="text-white">{model.supportedAspectRatios.join(', ')}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500">Resolutions:</span>
                  <span className="text-white">{model.supportedResolutions.join(', ')}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500">Video Extension:</span>
                  <span className={model.supportsExtension ? 'text-emerald-400' : 'text-neutral-600'}>
                    {model.supportsExtension ? 'Yes (720p)' : 'No'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500">Native Audio:</span>
                  <span className={model.supportsAudio ? 'text-emerald-400' : 'text-neutral-600'}>
                    {model.supportsAudio ? 'Supported' : 'No'}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 3. Server Processing & Assembly (FFmpeg) */}
      <div className="rounded-2xl border border-neutral-800 bg-neutral-900/40 p-5 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <FileVideo className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Video Assembly & Concatenation Engine</h2>
              <p className="text-xs text-neutral-400">FFmpeg normalization, audio re-encoding, and MP4 generation</p>
            </div>
          </div>

          <div
            className={`flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-md border ${
              systemStatus?.ffmpegAvailable
                ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-400'
                : 'border-rose-500/30 bg-rose-500/10 text-rose-400'
            }`}
          >
            {systemStatus?.ffmpegAvailable ? (
              <>
                <CheckCircle2 className="w-4 h-4" />
                <span>FFmpeg Active (/usr/bin/ffmpeg)</span>
              </>
            ) : (
              <>
                <AlertCircle className="w-4 h-4" />
                <span>FFmpeg Missing</span>
              </>
            )}
          </div>
        </div>

        <p className="text-xs text-neutral-400 leading-relaxed">
          The server utilizes a native FFmpeg engine to assemble multi-clip video projects up to 120 minutes. It handles
          frame rate normalization (30fps), resolution scaling, audio synchronization, and final MP4 encoding.
        </p>
      </div>

      {/* 4. Persistent Storage Stats */}
      <div className="rounded-2xl border border-neutral-800 bg-neutral-900/40 p-5 space-y-4">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-lg bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
            <HardDrive className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white">Persistent Storage</h2>
            <p className="text-xs text-neutral-400">Clips and final video files cached in server storage</p>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div className="p-3.5 rounded-xl border border-neutral-800 bg-neutral-950 font-mono">
            <span className="text-neutral-500">Clips Stored</span>
            <p className="text-base font-bold text-white mt-0.5 tabular-nums">
              {systemStatus?.storageStats?.clipCount ?? 0}
            </p>
          </div>

          <div className="p-3.5 rounded-xl border border-neutral-800 bg-neutral-950 font-mono">
            <span className="text-neutral-500">Assembled Videos</span>
            <p className="text-base font-bold text-white mt-0.5 tabular-nums">
              {systemStatus?.storageStats?.finalCount ?? 0}
            </p>
          </div>

          <div className="p-3.5 rounded-xl border border-neutral-800 bg-neutral-950 font-mono">
            <span className="text-neutral-500">Disk Footprint</span>
            <p className="text-base font-bold text-cyan-400 mt-0.5 tabular-nums">
              {systemStatus?.storageStats?.totalSizeMb ?? 0} MB
            </p>
          </div>

          <div className="p-3.5 rounded-xl border border-neutral-800 bg-neutral-950 font-mono">
            <span className="text-neutral-500">Worker Jobs</span>
            <p className="text-base font-bold text-emerald-400 mt-0.5 tabular-nums">
              {systemStatus?.workerActiveJobs ?? 0}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
