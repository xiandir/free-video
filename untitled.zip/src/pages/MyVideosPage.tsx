import React, { useState } from 'react';
import {
  Film,
  Play,
  Download,
  Trash2,
  Search,
  ExternalLink,
  Clock,
  Layers,
  Sparkles,
  ArrowUpDown,
} from 'lucide-react';
import { Project } from '../types';
import { ApiService } from '../services/api';
import { DeleteConfirmModal } from '../components/DeleteConfirmModal';

interface MyVideosPageProps {
  projects: Project[];
  onNavigate: (tab: string, projectId?: string) => void;
  onPreviewVideo: (url: string, title: string) => void;
  onRefresh: () => void;
}

export const MyVideosPage: React.FC<MyVideosPageProps> = ({
  projects,
  onNavigate,
  onPreviewVideo,
  onRefresh,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [sortOption, setSortOption] = useState('newest');
  const [projectToDelete, setProjectToDelete] = useState<Project | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // Filter only projects that have final videos or completed clips
  const videos = projects.filter((p) => p.status === 'COMPLETED' || p.finalVideoUrl || p.completedClips > 0);

  // Search filtering
  const filteredVideos = videos.filter((p) => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      p.title.toLowerCase().includes(q) ||
      p.prompt.toLowerCase().includes(q) ||
      p.style.toLowerCase().includes(q) ||
      p.createdAt.includes(q)
    );
  });

  // Sorting
  filteredVideos.sort((a, b) => {
    if (sortOption === 'oldest') {
      return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
    }
    if (sortOption === 'longest') {
      return b.requestedDuration - a.requestedDuration;
    }
    if (sortOption === 'shortest') {
      return a.requestedDuration - b.requestedDuration;
    }
    // 'newest' default
    return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
  });

  const handleDelete = async () => {
    if (!projectToDelete) return;
    setIsDeleting(true);
    try {
      await ApiService.deleteProject(projectToDelete.id);
      setProjectToDelete(null);
      onRefresh();
    } catch (err) {
      console.error('Failed to delete video project:', err);
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in pb-16">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-white">My Videos</h1>
          <p className="text-xs sm:text-sm text-neutral-400">
            Browse and download all your finished long-form video productions
          </p>
        </div>

        <button
          onClick={() => onNavigate('create')}
          className="self-start sm:self-auto px-4 py-2 text-xs font-semibold text-neutral-950 bg-cyan-400 hover:bg-cyan-300 rounded-xl transition-all cursor-pointer whitespace-nowrap"
        >
          Create New Video
        </button>
      </div>

      {/* Search & Sort Filters */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-neutral-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by title, prompt, or date..."
            className="w-full pl-9 pr-4 py-2 rounded-xl border border-neutral-800 bg-neutral-900/60 text-xs text-white placeholder-neutral-500 focus:border-cyan-500 focus:outline-none"
          />
        </div>

        <div className="flex items-center gap-2 self-end sm:self-auto text-xs">
          <ArrowUpDown className="w-3.5 h-3.5 text-neutral-400" />
          <span className="text-neutral-500">Sort by:</span>
          <select
            value={sortOption}
            onChange={(e) => setSortOption(e.target.value)}
            className="px-2.5 py-1.5 rounded-lg border border-neutral-800 bg-neutral-900/60 text-xs text-white focus:outline-none"
          >
            <option value="newest">Newest</option>
            <option value="oldest">Oldest</option>
            <option value="longest">Longest Duration</option>
            <option value="shortest">Shortest Duration</option>
          </select>
        </div>
      </div>

      {/* Videos Grid */}
      {filteredVideos.length === 0 ? (
        <div className="p-12 rounded-3xl border border-neutral-800/80 bg-neutral-900/20 text-center space-y-4">
          <div className="w-14 h-14 rounded-2xl bg-neutral-800/50 mx-auto flex items-center justify-center text-neutral-500">
            <Film className="w-7 h-7" />
          </div>
          <div className="space-y-1">
            <h3 className="text-base font-semibold text-white">No videos yet.</h3>
            <p className="text-xs text-neutral-400">Your generated videos will appear here.</p>
          </div>
          <button
            onClick={() => onNavigate('create')}
            className="px-4 py-2 text-xs font-semibold text-neutral-950 bg-cyan-400 hover:bg-cyan-300 rounded-lg transition-all cursor-pointer"
          >
            Create Your First Video
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredVideos.map((project) => {
            const durationMin = Math.round(project.requestedDuration / 60);
            const durationLabel =
              project.requestedDuration >= 60
                ? `${durationMin} min (${project.requestedDuration}s)`
                : `${project.requestedDuration}s`;
            const createdDate = new Date(project.createdAt).toLocaleDateString(undefined, {
              year: 'numeric',
              month: 'short',
              day: 'numeric',
            });

            const downloadFilename = project.finalVideoUrl
              ? project.finalVideoUrl.split('/').pop()
              : `${project.id}.mp4`;
            const downloadUrl = `/api/storage/download/${downloadFilename}`;

            return (
              <div
                key={project.id}
                className="group rounded-2xl border border-neutral-800 bg-neutral-900/40 overflow-hidden hover:border-neutral-700 transition-all flex flex-col justify-between"
              >
                {/* Thumbnail / Video Preview Box */}
                <div className="relative aspect-video w-full bg-neutral-950 flex items-center justify-center overflow-hidden">
                  {project.finalVideoUrl ? (
                    <video
                      src={project.finalVideoUrl}
                      className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-300"
                      muted
                      playsInline
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-gradient-to-tr from-neutral-950 to-neutral-900">
                      <Film className="w-8 h-8 text-neutral-700" />
                    </div>
                  )}

                  {/* Play overlay button */}
                  {project.finalVideoUrl && (
                    <button
                      onClick={() => onPreviewVideo(project.finalVideoUrl!, project.title)}
                      className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
                    >
                      <div className="w-12 h-12 rounded-full bg-cyan-400 text-neutral-950 flex items-center justify-center shadow-lg transform group-hover:scale-110 transition-transform">
                        <Play className="w-5 h-5 ml-0.5 fill-current" />
                      </div>
                    </button>
                  )}

                  {/* Corner duration badge */}
                  <div className="absolute bottom-2.5 right-2.5 px-2 py-0.5 rounded-md bg-neutral-950/80 backdrop-blur-md text-[10px] font-mono text-white border border-neutral-800">
                    {durationLabel}
                  </div>

                  <div className="absolute top-2.5 left-2.5 px-2 py-0.5 rounded-md bg-neutral-950/80 backdrop-blur-md text-[10px] font-mono text-cyan-400 border border-neutral-800">
                    {project.resolution}
                  </div>
                </div>

                {/* Details */}
                <div className="p-4 space-y-3 flex-1 flex flex-col justify-between">
                  <div className="space-y-1">
                    <h3 className="text-sm font-bold text-white group-hover:text-cyan-400 transition-colors truncate">
                      {project.title}
                    </h3>
                    <p className="text-xs text-neutral-400 line-clamp-2">{project.prompt}</p>
                  </div>

                  <div className="space-y-3 pt-2 border-t border-neutral-800/80">
                    <div className="flex items-center justify-between text-xs text-neutral-500">
                      <span>{createdDate}</span>
                      <span className="font-mono text-[11px]">{project.model.replace('-generate-preview', '')}</span>
                    </div>

                    <div className="flex items-center justify-between gap-2 pt-1">
                      <div className="flex items-center gap-1.5">
                        {project.finalVideoUrl && (
                          <a
                            href={downloadUrl}
                            download
                            className="p-1.5 rounded-lg text-neutral-300 hover:text-white hover:bg-neutral-800 transition-colors"
                            title="Download MP4"
                          >
                            <Download className="w-4 h-4" />
                          </a>
                        )}
                        <button
                          onClick={() => setProjectToDelete(project)}
                          className="p-1.5 rounded-lg text-neutral-400 hover:text-rose-400 hover:bg-neutral-800 transition-colors cursor-pointer"
                          title="Delete Video"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>

                      <button
                        onClick={() => onNavigate('project-detail', project.id)}
                        className="px-3 py-1.5 text-xs font-semibold text-white bg-neutral-800 hover:bg-neutral-700 rounded-lg transition-colors cursor-pointer"
                      >
                        Open Project
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Delete Confirmation Modal */}
      <DeleteConfirmModal
        isOpen={Boolean(projectToDelete)}
        title={projectToDelete?.title || ''}
        onClose={() => setProjectToDelete(null)}
        onConfirm={handleDelete}
        isDeleting={isDeleting}
      />
    </div>
  );
};
