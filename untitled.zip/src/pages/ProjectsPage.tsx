import React, { useState } from 'react';
import {
  FolderKanban,
  Search,
  Plus,
  Play,
  Trash2,
  ExternalLink,
  RotateCw,
  Clock,
  Layers,
  ArrowUpDown,
} from 'lucide-react';
import { Project } from '../types';
import { ApiService } from '../services/api';
import { DeleteConfirmModal } from '../components/DeleteConfirmModal';

interface ProjectsPageProps {
  projects: Project[];
  onNavigate: (tab: string, projectId?: string) => void;
  onRefresh: () => void;
}

export const ProjectsPage: React.FC<ProjectsPageProps> = ({ projects, onNavigate, onRefresh }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [sortOption, setSortOption] = useState('newest');
  const [projectToDelete, setProjectToDelete] = useState<Project | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const statuses = [
    { id: 'all', label: 'All Projects' },
    { id: 'generating', label: 'Generating' },
    { id: 'completed', label: 'Completed' },
    { id: 'draft', label: 'Draft' },
    { id: 'failed', label: 'Failed' },
    { id: 'cancelled', label: 'Cancelled' },
  ];

  // Filter projects
  const filteredProjects = projects.filter((p) => {
    if (statusFilter !== 'all' && p.status.toLowerCase() !== statusFilter) return false;
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      p.title.toLowerCase().includes(q) ||
      p.prompt.toLowerCase().includes(q) ||
      p.style.toLowerCase().includes(q)
    );
  });

  // Sort
  filteredProjects.sort((a, b) => {
    if (sortOption === 'oldest') {
      return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
    }
    if (sortOption === 'longest') {
      return b.requestedDuration - a.requestedDuration;
    }
    if (sortOption === 'shortest') {
      return a.requestedDuration - b.requestedDuration;
    }
    return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
  });

  const handleDelete = async () => {
    if (!projectToDelete) return;
    setIsDeleting(true);
    try {
      await ApiService.deleteProject(projectToDelete.id);
      setProjectToDelete(null);
      onRefresh();
    } catch (err) {
      console.error('Failed to delete project:', err);
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in pb-16">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-white">Projects</h1>
          <p className="text-xs sm:text-sm text-neutral-400">
            Manage your AI video production pipelines and scene breakdowns
          </p>
        </div>

        <button
          onClick={() => onNavigate('create')}
          className="self-start sm:self-auto flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-neutral-950 bg-cyan-400 hover:bg-cyan-300 rounded-xl transition-all cursor-pointer whitespace-nowrap"
        >
          <Plus className="w-4 h-4 stroke-[2.5]" />
          <span>New Project</span>
        </button>
      </div>

      {/* Interactive Filter Tabs (functional segmented controls per anti-slop rules) */}
      <div className="flex items-center gap-1 overflow-x-auto pb-1 scrollbar-none">
        {statuses.map((s) => (
          <button
            key={s.id}
            onClick={() => setStatusFilter(s.id)}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
              statusFilter === s.id
                ? 'bg-neutral-800 text-white font-semibold border border-neutral-700'
                : 'text-neutral-400 hover:text-white hover:bg-neutral-900'
            }`}
          >
            {s.label}
          </button>
        ))}
      </div>

      {/* Search and Sort Toolbar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-neutral-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search projects..."
            className="w-full pl-9 pr-4 py-2 rounded-xl border border-neutral-800 bg-neutral-900/60 text-xs text-white placeholder-neutral-500 focus:border-cyan-500 focus:outline-none"
          />
        </div>

        <div className="flex items-center gap-2 self-end sm:self-auto text-xs">
          <ArrowUpDown className="w-3.5 h-3.5 text-neutral-400" />
          <span className="text-neutral-500">Sort by:</span>
          <select
            value={sortOption}
            onChange={(e) => setSortOption(e.target.value)}
            className="px-2.5 py-1.5 rounded-lg border border-neutral-800 bg-neutral-900/60 text-xs text-white focus:outline-none"
          >
            <option value="newest">Newest</option>
            <option value="oldest">Oldest</option>
            <option value="longest">Longest Duration</option>
            <option value="shortest">Shortest Duration</option>
          </select>
        </div>
      </div>

      {/* Projects List */}
      {filteredProjects.length === 0 ? (
        <div className="p-12 rounded-3xl border border-neutral-800/80 bg-neutral-900/20 text-center space-y-4">
          <div className="w-14 h-14 rounded-2xl bg-neutral-800/50 mx-auto flex items-center justify-center text-neutral-500">
            <FolderKanban className="w-7 h-7" />
          </div>
          <div className="space-y-1">
            <h3 className="text-base font-semibold text-white">No projects yet.</h3>
            <p className="text-xs text-neutral-400">Create your first AI video to get started.</p>
          </div>
          <button
            onClick={() => onNavigate('create')}
            className="px-4 py-2 text-xs font-semibold text-neutral-950 bg-cyan-400 hover:bg-cyan-300 rounded-lg transition-all cursor-pointer"
          >
            Create New Project
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredProjects.map((project) => {
            const durationMin = Math.round(project.requestedDuration / 60);
            const durationLabel =
              project.requestedDuration >= 60
                ? `${durationMin} min (${project.requestedDuration}s)`
                : `${project.requestedDuration}s`;
            const createdDate = new Date(project.createdAt).toLocaleDateString(undefined, {
              year: 'numeric',
              month: 'short',
              day: 'numeric',
            });

            return (
              <div
                key={project.id}
                className="p-4 sm:p-5 rounded-2xl border border-neutral-800 bg-neutral-900/40 hover:border-neutral-700 transition-colors flex flex-col md:flex-row md:items-center justify-between gap-4"
              >
                <div className="space-y-2 min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2.5">
                    <h3
                      onClick={() => onNavigate('project-detail', project.id)}
                      className="text-base font-bold text-white hover:text-cyan-400 transition-colors cursor-pointer truncate"
                    >
                      {project.title}
                    </h3>

                    <span
                      className={`text-[10px] font-semibold px-2 py-0.5 rounded border ${
                        project.status === 'COMPLETED'
                          ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-400'
                          : project.status === 'GENERATING' || project.status === 'ASSEMBLING'
                          ? 'border-cyan-500/30 bg-cyan-500/10 text-cyan-400 animate-pulse'
                          : project.status === 'FAILED'
                          ? 'border-rose-500/30 bg-rose-500/10 text-rose-400'
                          : 'border-neutral-800 bg-neutral-950 text-neutral-400'
                      }`}
                    >
                      {project.status}
                    </span>
                  </div>

                  <p className="text-xs text-neutral-400 line-clamp-1">{project.prompt}</p>

                  <div className="flex flex-wrap items-center gap-3 text-xs text-neutral-500 font-mono">
                    <span className="tabular-nums">Duration: {durationLabel}</span>
                    <span>·</span>
                    <span className="tabular-nums">
                      Clips: {project.completedClips} / {project.totalClips}
                    </span>
                    <span>·</span>
                    <span>Format: {project.resolution}</span>
                    <span>·</span>
                    <span>{createdDate}</span>
                  </div>
                </div>

                {/* Progress bar on tablet/desktop */}
                <div className="w-full md:w-48 space-y-1">
                  <div className="flex items-center justify-between text-[11px] text-neutral-400 font-mono">
                    <span>Progress</span>
                    <span className="text-neutral-200 tabular-nums">{project.progress}%</span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-neutral-950 overflow-hidden border border-neutral-800">
                    <div
                      className={`h-full transition-all duration-300 ${
                        project.status === 'COMPLETED'
                          ? 'bg-emerald-400'
                          : project.status === 'FAILED'
                          ? 'bg-rose-500'
                          : 'bg-cyan-400'
                      }`}
                      style={{ width: `${project.progress}%` }}
                    />
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-2 self-end md:self-center">
                  <button
                    onClick={() => setProjectToDelete(project)}
                    className="p-2 rounded-lg text-neutral-400 hover:text-rose-400 hover:bg-neutral-800 transition-colors cursor-pointer"
                    title="Delete Project"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => onNavigate('project-detail', project.id)}
                    className="px-3.5 py-1.5 text-xs font-semibold text-white bg-neutral-800 hover:bg-neutral-700 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                  >
                    Open Project
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Delete Confirmation Modal */}
      <DeleteConfirmModal
        isOpen={Boolean(projectToDelete)}
        title={projectToDelete?.title || ''}
        onClose={() => setProjectToDelete(null)}
        onConfirm={handleDelete}
        isDeleting={isDeleting}
      />
    </div>
  );
};
