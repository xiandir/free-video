# FREEVIDAi

> **"Turn Your Ideas Into AI Videos"**  
> *Create. Imagine. Generate.*

FREEVIDAi is a production-oriented AI video generation platform designed around Google's Gemini and Veo APIs. It orchestrates short model clips (4s, 6s, 8s) into coherent long-form video productions of up to **120 minutes (2 hours)** with multi-chapter structuring, contextual visual continuity, native audio synthesis, and server-side FFmpeg assembly.

---

## 1. System Architecture

The application implements a multi-stage asynchronous video pipeline:

```
[ User Prompt & Duration (up to 120m) ]
               │
               ▼
[ Prompt Validation & Gemini 3.8 Flash Enhancement ]
               │
               ▼
[ AI Production Planning Engine ]
   ├── Narrative Chapters
   ├── Individual Scene Breakdowns (4s / 6s / 8s)
   └── Context-Aware Continuity Rules (Characters, Lighting, Camera)
               │
               ▼
[ Dynamic Clip Calculation ]  (e.g., 120 min = 7,200s / 8s = 900 clips)
               │
               ▼
[ Asynchronous Job Queue & Worker Service ]
   ├── Google Veo 3.1 API Clip Generation
   ├── Polling Operations & Provider Stream Download
   └── Persistent Storage Caching (/data/storage/clips)
               │
               ▼
[ Resumable Engine & Failure Isolation ]
   └── Failed clip retries without regenerating successful clips
               │
               ▼
[ Video Assembly Service ]
   └── FFmpeg normalization (30fps, 720p/1080p, AAC audio) & concatenation
               │
               ▼
[ Final Assembled MP4 Video & Persistent Storage ]
```

---

## 2. Model Capabilities & Configurations

FREEVIDAi centralizes all video model capabilities through `ModelCapabilityService`:

| Model ID | Durations | Aspect Ratios | Resolutions | Extension | Reference Images | Native Audio |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `veo-3.1-generate-preview` | 4s, 6s, 8s | 16:9, 9:16 | 720p, 1080p, 4k | Yes (720p) | Yes (16:9 720p) | Yes |
| `veo-3.1-lite-generate-preview` | 4s, 6s, 8s | 16:9, 9:16 | 720p, 1080p | No | No | Yes |

- **Clip Calculation**: Dynamically computes required clips: $\text{Total Clips} = \lceil \frac{\text{Duration (seconds)}}{\text{Clip Duration (seconds)}} \rceil$.
- **Project Limits**: Supports projects from 10 seconds up to **120 minutes** (7,200 seconds).

---

## 3. Environment Variables

Define the following environment variables in `.env` (refer to `.env.example`):

```bash
# GEMINI_API_KEY: Required for Gemini text planning and Veo video generation.
# In Google AI Studio, this is automatically injected from user secrets.
GEMINI_API_KEY="YOUR_GOOGLE_AI_API_KEY"

# PORT: Server port (defaults to 3000)
PORT=3000

# APP_URL: The hosting URL (injected by Cloud Run in AI Studio)
APP_URL="https://your-domain.run.app"
```

> **Security Note:** The `GEMINI_API_KEY` is exclusively accessed server-side via `process.env.GEMINI_API_KEY`. It is never bundled into client JavaScript or sent to browsers.

---

## 4. Installation & Local Development

### Prerequisites
- Node.js 18+ or Bun
- FFmpeg installed on system path (`/usr/bin/ffmpeg`)

### Setup Commands
```bash
# 1. Install dependencies
npm install

# 2. Run full-stack development server (Express + Vite)
npm run dev

# 3. Build for production
npm run build

# 4. Start production server
npm run start
```

---

## 5. Storage & Database Architecture

- **Database**: File-backed JSON store in `data/db.json` tracking projects, chapters, scenes, retry counts, operation IDs, and generation progress.
- **Storage**:
  - `data/storage/clips/`: Individual scene clips downloaded from the Veo provider before temporary retention expires.
  - `data/storage/final/`: Final concatenated MP4 projects.
  - `data/temp/`: Temporary FFmpeg concatenation manifests.
- **HTTP Video Streaming**: Supports `Range` header requests for fluid seeking and immediate playback in all standard web browsers.

---

## 6. Continuity Engine & Long-Form Consistency

To ensure that 100+ clips in a multi-hour documentary or cinematic short do not look like disjointed random videos, `ContinuityService`:
1. Extracts world state (lighting, weather, vehicle styles, color palette, camera motion).
2. For each successive shot, prefixes previous scene context:
   `"Continuing directly and seamlessly from the previous shot... Maintain identical visual continuity: preserve the same lighting..."`
3. Dynamically incorporates camera direction (aerial drone, tracking shot, low-angle reveal) for seamless shot-to-shot pacing.

---

## 7. Resumable Generation & Fault Tolerance

If clip 483 in a 900-clip project fails due to a network glitch or provider rate-limit:
1. Clips 1–482 remain stored on disk.
2. Clip 483 is marked `FAILED` with the exact provider error.
3. The user can click **Retry Failed Clips**.
4. The worker retries only the failed scene(s) and resumes FFmpeg assembly upon completion.
5. Users can safely pause, cancel, or leave the app and return to resume anytime.

---

## 8. Video Assembly with FFmpeg

Once all clips for a project are marked `COMPLETED`:
1. The server compiles an ordered concat demuxer manifest.
2. FFmpeg validates and normalizes clips (scaling to selected aspect ratio, standardizing 30fps and AAC audio).
3. The final assembled MP4 is rendered directly to persistent storage and made available for instant in-browser playback and one-click download.

---

## 9. Troubleshooting

- **"Video generation is not configured yet"**: Verify that `GEMINI_API_KEY` is added to your AI Studio Secrets panel.
- **"FFmpeg is not installed"**: Ensure FFmpeg is available on the system path (`ffmpeg -version`).
- **Quota Exceeded (HTTP 429)**: The queue isolates failed clips and allows retrying after provider rate limits reset.
