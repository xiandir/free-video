import express from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { db } from './server/database/db';
import { isApiKeyConfigured } from './server/services/geminiClient';
import { PlanningService } from './server/services/planningService';
import { StorageService } from './server/services/storageService';
import { VideoAssemblyService } from './server/services/videoAssemblyService';
import { JobQueueService } from './server/services/jobQueueService';
import { ModelCapabilityService, MAX_PROJECT_DURATION_SECONDS } from './src/config/modelCapabilities';
import { Project } from './src/types';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

  StorageService.init();

  app.use(express.json({ limit: '10mb' }));
  app.use(express.urlencoded({ extended: true }));

  // ==========================================
  // API ROUTES
  // ==========================================

  // 1. System Status
  app.get('/api/system/status', async (req, res) => {
    try {
      const ffmpegAvailable = await VideoAssemblyService.checkFfmpeg();
      const storageStats = StorageService.getStorageStats();
      const projects = db.getProjects();

      res.json({
        apiConfigured: isApiKeyConfigured(),
        ffmpegAvailable,
        activeModel: 'veo-3.1-generate-preview',
        totalProjects: projects.length,
        totalClipsStored: storageStats.clipCount,
        storageStats,
        workerActiveJobs: JobQueueService.getActiveJobsCount(),
      });
    } catch (err: any) {
      res.status(500).json({ error: err?.message || 'Failed to get system status' });
    }
  });

  // 2. Enhance Prompt with Gemini
  app.post('/api/ai/enhance-prompt', async (req, res) => {
    try {
      const { prompt, style } = req.body;
      if (!prompt || typeof prompt !== 'string') {
        return res.status(400).json({ error: 'Prompt is required.' });
      }

      const enhanced = await PlanningService.enhancePrompt(prompt, style);
      res.json({ enhancedPrompt: enhanced });
    } catch (err: any) {
      res.status(500).json({ error: err?.message || 'Failed to enhance prompt' });
    }
  });

  // 3. Create Video Project & Video Plan
  app.post('/api/projects', async (req, res) => {
    try {
      const {
        prompt,
        enhancedPrompt,
        durationSeconds = 60,
        modelId = 'veo-3.1-generate-preview',
        style = 'Cinematic',
        aspectRatio = '16:9',
        resolution = '720p',
        audioEnabled = true,
        audioInstructions,
      } = req.body;

      if (!prompt || typeof prompt !== 'string' || prompt.trim() === '') {
        return res.status(400).json({ error: 'Video prompt description is required.' });
      }

      if (durationSeconds > MAX_PROJECT_DURATION_SECONDS) {
        return res.status(400).json({
          error: 'FREEVIDAi currently supports projects up to 120 minutes (7,200 seconds).',
        });
      }

      // Generate structured production plan
      const plan = await PlanningService.createVideoPlan({
        prompt: prompt.trim(),
        enhancedPrompt: enhancedPrompt?.trim(),
        durationSeconds: Math.min(Math.max(4, Number(durationSeconds)), MAX_PROJECT_DURATION_SECONDS),
        modelId,
        style,
        aspectRatio,
        resolution,
        audioEnabled: Boolean(audioEnabled),
      });

      const projectId = `proj_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;

      const newProject: Project = {
        id: projectId,
        title: plan.title,
        description: plan.description,
        prompt: prompt.trim(),
        enhancedPrompt: enhancedPrompt?.trim() || prompt.trim(),
        requestedDuration: durationSeconds,
        model: modelId,
        aspectRatio,
        resolution,
        style,
        audioEnabled: Boolean(audioEnabled),
        audioInstructions,
        status: 'DRAFT',
        totalClips: plan.totalClips,
        completedClips: 0,
        failedClips: 0,
        currentClipIndex: 0,
        progress: 0,
        currentStatusMessage: 'Project plan ready. Start generation to begin video rendering.',
        chapters: plan.chapters,
        continuity: plan.continuity,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      db.saveProject(newProject);
      res.json({ project: newProject });
    } catch (err: any) {
      console.error('Error creating project:', err);
      res.status(500).json({ error: err?.message || 'Failed to create project' });
    }
  });

  // 4. List Projects (with Search & Sorting)
  app.get('/api/projects', (req, res) => {
    try {
      let projects = db.getProjects();
      const { search, sort, status } = req.query as { search?: string; sort?: string; status?: string };

      if (status && status !== 'all') {
        projects = projects.filter((p) => p.status.toLowerCase() === status.toLowerCase());
      }

      if (search && search.trim()) {
        const query = search.toLowerCase().trim();
        projects = projects.filter(
          (p) =>
            p.title.toLowerCase().includes(query) ||
            p.prompt.toLowerCase().includes(query) ||
            p.style.toLowerCase().includes(query)
        );
      }

      if (sort) {
        if (sort === 'oldest') {
          projects.sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
        } else if (sort === 'longest') {
          projects.sort((a, b) => b.requestedDuration - a.requestedDuration);
        } else if (sort === 'shortest') {
          projects.sort((a, b) => a.requestedDuration - b.requestedDuration);
        } else if (sort === 'completed') {
          projects.sort((a, b) => (b.status === 'COMPLETED' ? 1 : 0) - (a.status === 'COMPLETED' ? 1 : 0));
        } else if (sort === 'processing') {
          projects.sort((a, b) => (b.status === 'GENERATING' ? 1 : 0) - (a.status === 'GENERATING' ? 1 : 0));
        } else {
          // 'newest' default
          projects.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        }
      }

      res.json({ projects });
    } catch (err: any) {
      res.status(500).json({ error: err?.message || 'Failed to list projects' });
    }
  });

  // 5. Get Project Detail & Live Status
  app.get('/api/projects/:id', (req, res) => {
    try {
      const project = db.getProjectById(req.params.id);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }
      res.json({ project });
    } catch (err: any) {
      res.status(500).json({ error: err?.message || 'Failed to get project' });
    }
  });

  // 6. Delete Project & Associated Clips & Final Video
  app.delete('/api/projects/:id', (req, res) => {
    try {
      const project = db.getProjectById(req.params.id);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      // Delete storage files
      StorageService.deleteFinalVideo(project.id);
      for (const chapter of project.chapters) {
        for (const scene of chapter.scenes) {
          StorageService.deleteClip(scene.sceneId);
        }
      }

      db.deleteProject(project.id);
      res.json({ success: true, message: 'Project and all generated assets deleted.' });
    } catch (err: any) {
      res.status(500).json({ error: err?.message || 'Failed to delete project' });
    }
  });

  // 7. Start Generation
  app.post('/api/projects/:id/start', async (req, res) => {
    try {
      const project = db.getProjectById(req.params.id);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      await JobQueueService.startProject(project.id);
      const updated = db.getProjectById(project.id);
      res.json({ success: true, project: updated });
    } catch (err: any) {
      res.status(500).json({ error: err?.message || 'Failed to start generation' });
    }
  });

  // 8. Cancel Generation
  app.post('/api/projects/:id/cancel', (req, res) => {
    try {
      JobQueueService.cancelProject(req.params.id);
      const updated = db.getProjectById(req.params.id);
      res.json({ success: true, project: updated });
    } catch (err: any) {
      res.status(500).json({ error: err?.message || 'Failed to cancel project' });
    }
  });

  // 9. Retry Failed Clips
  app.post('/api/projects/:id/retry-failed', async (req, res) => {
    try {
      await JobQueueService.retryFailedScenes(req.params.id);
      const updated = db.getProjectById(req.params.id);
      res.json({ success: true, project: updated });
    } catch (err: any) {
      res.status(500).json({ error: err?.message || 'Failed to retry failed clips' });
    }
  });

  // 10. Trigger Assembly
  app.post('/api/projects/:id/assemble', async (req, res) => {
    try {
      const project = db.getProjectById(req.params.id);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      project.status = 'ASSEMBLING';
      db.saveProject(project);

      const result = await VideoAssemblyService.assembleProject(project);
      if (result.success && result.finalVideoUrl) {
        project.status = 'COMPLETED';
        project.finalVideoUrl = result.finalVideoUrl;
        project.finalVideoPath = result.finalVideoPath;
        project.currentStatusMessage = 'Your video is ready.';
        db.saveProject(project);
        res.json({ success: true, project });
      } else {
        project.status = 'FAILED';
        project.error = result.error;
        db.saveProject(project);
        res.status(400).json({ success: false, error: result.error });
      }
    } catch (err: any) {
      res.status(500).json({ error: err?.message || 'Failed to assemble video' });
    }
  });

  // ==========================================
  // VIDEO STREAMING & STORAGE SERVING
  // ==========================================

  // Stream clips with HTTP range support
  app.get('/api/storage/clips/:filename', (req, res) => {
    const { filename } = req.params;
    const { filePath, exists } = StorageService.getClip(filename);
    if (!exists) {
      return res.status(404).send('Clip not found');
    }
    streamVideoFile(req, res, filePath);
  });

  // Stream final assembled video with HTTP range support
  app.get('/api/storage/videos/:filename', (req, res) => {
    const { filename } = req.params;
    const { filePath, exists } = StorageService.getFinalVideo(filename);
    if (!exists) {
      return res.status(404).send('Video not found');
    }
    streamVideoFile(req, res, filePath);
  });

  // Force file download attachment
  app.get('/api/storage/download/:filename', (req, res) => {
    const { filename } = req.params;
    const { filePath, exists } = StorageService.getFinalVideo(filename);
    if (!exists) {
      return res.status(404).send('Video not found');
    }
    res.download(filePath, `FREEVIDAi_${filename}`);
  });

  // ==========================================
  // VITE DEV SERVER / PRODUCTION SERVING
  // ==========================================
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`FREEVIDAi server running on port ${PORT}`);
  });
}

function streamVideoFile(req: express.Request, res: express.Response, filePath: string) {
  const stat = fs.statSync(filePath);
  const fileSize = stat.size;
  const range = req.headers.range;

  if (range) {
    const parts = range.replace(/bytes=/, '').split('-');
    const start = parseInt(parts[0], 10);
    const end = parts[1] ? parseInt(parts[1], 10) : fileSize - 1;
    const chunksize = end - start + 1;
    const file = fs.createReadStream(filePath, { start, end });
    const head = {
      'Content-Range': `bytes ${start}-${end}/${fileSize}`,
      'Accept-Ranges': 'bytes',
      'Content-Length': chunksize,
      'Content-Type': 'video/mp4',
    };
    res.writeHead(206, head);
    file.pipe(res);
  } else {
    const head = {
      'Content-Length': fileSize,
      'Content-Type': 'video/mp4',
    };
    res.writeHead(200, head);
    fs.createReadStream(filePath).pipe(res);
  }
}

startServer().catch((err) => {
  console.error('Server startup failed:', err);
  process.exit(1);
});
